-- DOLIA Realtime: private Studio-specific Broadcast channels
-- Topic used by the APK:
--   realtime:dolia_studio_<STUDIO_USER_ID>
--
-- Existing DOLIA schema uses public.profiles, while the Controller's
-- studio pairing is stored in Supabase Auth user_metadata as studio_user_id.
-- Do not reference a separate/nonexistent dolia_profiles table here.

alter table realtime.messages enable row level security;

grant usage on schema realtime to authenticated;
grant select, insert on realtime.messages to authenticated;

drop policy if exists "dolia_receive_own_studio_broadcasts" on realtime.messages;
create policy "dolia_receive_own_studio_broadcasts"
on realtime.messages
for select
to authenticated
using (
  extension = 'broadcast'
  and exists (
    select 1
    from public.profiles p
    where p.id = (select auth.uid())
      and (
        (
          p.role = 'dolia'
          and p.id::text = replace((select realtime.topic()), 'realtime:dolia_studio_', '')
        )
        or
        (
          p.role = 'controller'
          and (select auth.jwt() -> 'user_metadata' ->> 'studio_user_id') =
              replace((select realtime.topic()), 'realtime:dolia_studio_', '')
        )
      )
  )
);

drop policy if exists "dolia_send_own_studio_broadcasts" on realtime.messages;
create policy "dolia_send_own_studio_broadcasts"
on realtime.messages
for insert
to authenticated
with check (
  extension = 'broadcast'
  and exists (
    select 1
    from public.profiles p
    where p.id = (select auth.uid())
      and (
        (
          p.role = 'dolia'
          and p.id::text = replace((select realtime.topic()), 'realtime:dolia_studio_', '')
        )
        or
        (
          p.role = 'controller'
          and (select auth.jwt() -> 'user_metadata' ->> 'studio_user_id') =
              replace((select realtime.topic()), 'realtime:dolia_studio_', '')
        )
      )
  )
);

-- Optional diagnostic query:
-- SELECT id, username, role FROM public.profiles ORDER BY created_at;
-- For Controller accounts, confirm Auth > User Metadata contains:
-- { "studio_user_id": "<DOLIA_STUDIO_USER_UUID>" }
