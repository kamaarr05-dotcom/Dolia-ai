# DOLIA — Login tanpa verifikasi email

DOLIA menggunakan login email/username + password. Proses LOGIN tidak memanggil signup, OTP, magic link, resend email, atau endpoint pengiriman email.

## Supabase Cloud

Di Dashboard Supabase buka:

**Authentication → Providers → Email → Confirm Email = OFF**

Pengaturan ini wajib untuk user baru agar login password tidak menunggu konfirmasi email.

## User yang sudah terlanjur dibuat

Jalankan `CONFIRM_AUTH_USERS.sql` di SQL Editor. Script hanya mengisi `auth.users.email_confirmed_at` dan sengaja tidak mengubah `confirmed_at`, karena pada beberapa versi Supabase `confirmed_at` adalah generated column.

## Catatan keamanan

- Password tidak disimpan dalam database aplikasi.
- Jangan masukkan service-role key ke APK.
- Login Android tetap menggunakan endpoint password Supabase (`grant_type=password`).
- Tidak ada cara aman bagi APK client dengan anon key untuk memaksa `email_confirmed_at`; status tersebut harus diatur oleh Supabase Auth (Dashboard/Admin API/SQL sesuai akses project).
