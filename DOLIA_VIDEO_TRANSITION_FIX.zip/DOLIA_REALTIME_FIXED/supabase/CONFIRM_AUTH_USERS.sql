-- DOLIA: NONAKTIFKAN KEBUTUHAN VERIFIKASI EMAIL UNTUK USER AUTH YANG SUDAH ADA
-- Jalankan di Supabase SQL Editor.
-- Tidak mengubah password dan TIDAK menyentuh confirmed_at karena
-- pada beberapa versi Supabase confirmed_at adalah generated column.

-- Tandai seluruh user email yang sudah ada sebagai confirmed.
UPDATE auth.users
SET email_confirmed_at = COALESCE(email_confirmed_at, now())
WHERE email IS NOT NULL;

-- Pastikan akun DOLIA Studio ini confirmed.
UPDATE auth.users
SET email_confirmed_at = COALESCE(email_confirmed_at, now())
WHERE lower(email) = lower('mdqputra@gmail.com');

-- Verifikasi hasil.
SELECT id, email, email_confirmed_at
FROM auth.users
WHERE lower(email) = lower('mdqputra@gmail.com');

-- PENTING UNTUK SUPABASE CLOUD:
-- Authentication -> Providers -> Email -> Confirm Email = OFF.
-- Setting tersebut adalah pengaturan Auth Cloud yang permanen untuk user baru.
