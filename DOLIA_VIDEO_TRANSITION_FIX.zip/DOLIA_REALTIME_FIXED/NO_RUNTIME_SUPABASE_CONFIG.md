# DOLIA production configuration

DOLIA tidak meminta Supabase URL/Anon Key pada saat aplikasi sudah di-install. Endpoint dan publishable/anon key masuk ke `BuildConfig` saat APK dibuat.

## Build
GitHub Actions harus menerima:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Workflow sekarang gagal (bukan memakai placeholder) jika secrets tersebut kosong. Jadi APK yang lolos build sudah membawa endpoint backend yang benar.

## Realtime
Studio memakai topic `realtime:dolia_studio_<studio-user-id>`. Controller memakai `studio_id` milik pasangan tersebut. Channel dibuat private dan diotorisasi melalui `supabase/REALTIME_DOLIA_PRIVATE_CHANNELS.sql`.

## Auth
Login memakai password grant saja. Jangan menambahkan signup/OTP/magic-link ke jalur login.
