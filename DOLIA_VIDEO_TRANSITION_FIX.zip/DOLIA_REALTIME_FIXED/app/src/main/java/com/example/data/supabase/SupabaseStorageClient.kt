package com.example.data.supabase

import android.util.Log
import com.example.data.model.DoliaVideoItem
import com.example.data.model.VideoCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class SupabaseStorageClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    companion object {
        private const val TAG = "SupabaseStorage"
        private const val BUCKET_NAME = "dolia-videos"
    }

    private fun parseIsoTimestamp(isoString: String?): Long {
        if (isoString.isNullOrEmpty()) return System.currentTimeMillis()
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            val clean = isoString.substringBefore("+").substringBefore("Z")
            sdf.parse(clean)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }

    /**
     * Checks if bucket 'dolia-videos' exists, and attempts to create it if missing.
     */
    suspend fun ensureBucketExists(
        config: SupabaseConfig,
        token: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val checkUrl = "${config.cleanUrl}/storage/v1/bucket/$BUCKET_NAME"
            val checkRequest = Request.Builder()
                .url(checkUrl)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .get()
                .build()

            val exists = client.newCall(checkRequest).execute().use { response ->
                response.isSuccessful
            }

            if (exists) {
                return@withContext Result.success(true)
            }

            // Attempt to create bucket
            val createUrl = "${config.cleanUrl}/storage/v1/bucket"
            val payload = JSONObject().apply {
                put("id", BUCKET_NAME)
                put("name", BUCKET_NAME)
                put("public", true)
            }.toString()

            val createRequest = Request.Builder()
                .url(createUrl)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(createRequest).execute().use { response ->
                if (response.isSuccessful || response.code == 409) {
                    Result.success(true)
                } else {
                    Result.failure(IOException("Bucket '$BUCKET_NAME' belum tersedia di Supabase (Status: ${response.code}). Silakan buat bucket '$BUCKET_NAME' di menu Storage Supabase."))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Uploads video file directly to Supabase Storage bucket 'dolia-videos'
     * Streaming directly from File avoiding memory overhead or OutOfMemoryError.
     */
    suspend fun uploadVideoFromFile(
        config: SupabaseConfig,
        token: String,
        fileName: String,
        mimeType: String,
        file: java.io.File
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val uploadUrl = "${config.cleanUrl}/storage/v1/object/$BUCKET_NAME/$fileName"
            Log.d(TAG, "Uploading video file (${file.length()} bytes) to $uploadUrl")

            val effectiveMime = if (mimeType.isNotBlank()) mimeType else "video/mp4"
            val mediaType = try {
                effectiveMime.toMediaType()
            } catch (e: Exception) {
                "video/mp4".toMediaType()
            }

            // Stream directly from File
            val fileRequestBody = file.asRequestBody(mediaType)

            val request = Request.Builder()
                .url(uploadUrl)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .header("x-upsert", "true")
                .post(fileRequestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = try {
                        val json = JSONObject(body)
                        json.optString("message", json.optString("error", "Upload gagal (${response.code})"))
                    } catch (e: Exception) {
                        "Upload gagal (${response.code}): $body"
                    }
                    Log.e(TAG, "Storage upload failed: $errorMsg")
                    return@withContext Result.failure(IOException(errorMsg))
                }

                // Public URL for the uploaded video
                val publicUrl = "${config.cleanUrl}/storage/v1/object/public/$BUCKET_NAME/$fileName"
                Log.d(TAG, "Storage upload success. Public URL: $publicUrl")
                Result.success(publicUrl)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Storage upload file error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Uploads video binary data directly to Supabase Storage bucket 'dolia-videos'
     */
    suspend fun uploadVideo(
        config: SupabaseConfig,
        token: String,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val uploadUrl = "${config.cleanUrl}/storage/v1/object/$BUCKET_NAME/$fileName"
            Log.d(TAG, "Uploading video (${bytes.size} bytes) to $uploadUrl")

            val effectiveMime = if (mimeType.isNotBlank()) mimeType else "video/mp4"
            val mediaType = try {
                effectiveMime.toMediaType()
            } catch (e: Exception) {
                "video/mp4".toMediaType()
            }

            val request = Request.Builder()
                .url(uploadUrl)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .header("x-upsert", "true")
                .post(bytes.toRequestBody(mediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = try {
                        JSONObject(body).optString("message", "Upload gagal (${response.code})")
                    } catch (e: Exception) {
                        "Upload gagal (${response.code}): $body"
                    }
                    Log.e(TAG, "Storage upload failed: $errorMsg")
                    return@withContext Result.failure(IOException(errorMsg))
                }

                // Public URL for the uploaded video
                val publicUrl = "${config.cleanUrl}/storage/v1/object/public/$BUCKET_NAME/$fileName"
                Log.d(TAG, "Storage upload success. Public URL: $publicUrl")
                Result.success(publicUrl)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Storage upload error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Saves video metadata to PostgreSQL 'videos' table via PostgREST
     */
    suspend fun insertVideoMetadata(
        config: SupabaseConfig,
        token: String,
        video: DoliaVideoItem,
        userId: String
    ): Result<DoliaVideoItem> = withContext(Dispatchers.IO) {
        try {
            val url = "${config.restUrl}/videos"
            val payload = JSONObject().apply {
                put("id", video.id)
                put("name", video.name)
                put("category", video.category.value)
                put("url", video.url)
                put("storage_path", video.storagePath)
                put("size_bytes", video.sizeBytes)
                put("uploaded_by", userId)
                put("is_active_idle", video.isActiveIdle)
                put("is_active_speak", video.isActiveSpeak)
            }.toString()

            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .header("Prefer", "resolution=merge-duplicates,return=representation")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = try {
                        JSONObject(body).optString("message", "Gagal menyimpan metadata video (${response.code})")
                    } catch (e: Exception) {
                        "Gagal simpan video metadata (${response.code}): $body"
                    }
                    Log.e(TAG, "Insert video metadata failed: $errorMsg")
                    return@withContext Result.failure(IOException(errorMsg))
                }
                Result.success(video)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Insert video metadata error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches all registered videos from PostgreSQL 'videos' table
     */
    suspend fun fetchVideos(
        config: SupabaseConfig,
        token: String
    ): Result<List<DoliaVideoItem>> = withContext(Dispatchers.IO) {
        try {
            val url = "${config.restUrl}/videos?order=created_at.desc"
            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException("Gagal mengambil daftar video (${response.code})"))
                }
                val arr = JSONArray(body)
                val list = mutableListOf<DoliaVideoItem>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        DoliaVideoItem(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            category = VideoCategory.fromString(obj.optString("category", "idle")),
                            url = obj.getString("url"),
                            storagePath = obj.optString("storage_path", ""),
                            sizeBytes = obj.optLong("size_bytes", 0L),
                            isActiveIdle = obj.optBoolean("is_active_idle", false),
                            isActiveSpeak = obj.optBoolean("is_active_speak", false),
                            createdAt = parseIsoTimestamp(obj.optString("created_at", ""))
                        )
                    )
                }
                Result.success(list)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Fetch videos error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Sets a specific video as active IDLE or active SPEAK in PostgreSQL
     */
    suspend fun setActiveVideo(
        config: SupabaseConfig,
        token: String,
        videoId: String,
        setAsIdle: Boolean,
        setAsSpeak: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (setAsIdle) {
                // Reset other idle flags
                val resetPayload = JSONObject().apply { put("is_active_idle", false) }.toString()
                val resetReq = Request.Builder()
                    .url("${config.restUrl}/videos?is_active_idle=eq.true")
                    .header("apikey", config.anonKey)
                    .header("Authorization", "Bearer $token")
                    .header("Content-Type", "application/json")
                    .patch(resetPayload.toRequestBody(jsonMediaType))
                    .build()
                client.newCall(resetReq).execute().close()

                // Set this video as idle
                val setPayload = JSONObject().apply { put("is_active_idle", true) }.toString()
                val setReq = Request.Builder()
                    .url("${config.restUrl}/videos?id=eq.$videoId")
                    .header("apikey", config.anonKey)
                    .header("Authorization", "Bearer $token")
                    .header("Content-Type", "application/json")
                    .patch(setPayload.toRequestBody(jsonMediaType))
                    .build()
                client.newCall(setReq).execute().close()
            }

            if (setAsSpeak) {
                // Reset other speak flags
                val resetPayload = JSONObject().apply { put("is_active_speak", false) }.toString()
                val resetReq = Request.Builder()
                    .url("${config.restUrl}/videos?is_active_speak=eq.true")
                    .header("apikey", config.anonKey)
                    .header("Authorization", "Bearer $token")
                    .header("Content-Type", "application/json")
                    .patch(resetPayload.toRequestBody(jsonMediaType))
                    .build()
                client.newCall(resetReq).execute().close()

                // Set this video as speak
                val setPayload = JSONObject().apply { put("is_active_speak", true) }.toString()
                val setReq = Request.Builder()
                    .url("${config.restUrl}/videos?id=eq.$videoId")
                    .header("apikey", config.anonKey)
                    .header("Authorization", "Bearer $token")
                    .header("Content-Type", "application/json")
                    .patch(setPayload.toRequestBody(jsonMediaType))
                    .build()
                client.newCall(setReq).execute().close()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Set active video error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Deletes a video record and its storage asset
     */
    suspend fun deleteVideo(
        config: SupabaseConfig,
        token: String,
        videoId: String,
        storagePath: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Delete DB record
            val deleteDbReq = Request.Builder()
                .url("${config.restUrl}/videos?id=eq.$videoId")
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .delete()
                .build()
            client.newCall(deleteDbReq).execute().close()

            // Delete storage asset
            if (storagePath.isNotEmpty()) {
                val cleanPath = storagePath.removePrefix("$BUCKET_NAME/")
                val deleteStorageReq = Request.Builder()
                    .url("${config.cleanUrl}/storage/v1/object/$BUCKET_NAME/$cleanPath")
                    .header("apikey", config.anonKey)
                    .header("Authorization", "Bearer $token")
                    .delete()
                    .build()
                client.newCall(deleteStorageReq).execute().close()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Delete video error: ${e.message}", e)
            Result.failure(e)
        }
    }
}
