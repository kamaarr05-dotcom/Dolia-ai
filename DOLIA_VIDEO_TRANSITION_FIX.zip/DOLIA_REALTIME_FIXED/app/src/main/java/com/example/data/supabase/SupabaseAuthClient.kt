package com.example.data.supabase

import android.util.Log
import com.example.data.model.AuthUser
import com.example.data.model.UserRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class SupabaseAuthResult(
    val accessToken: String,
    val refreshToken: String,
    val user: AuthUser
)

class SupabaseAuthClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    companion object {
        private const val TAG = "SupabaseAuth"
    }

    private fun resolveEmail(input: String): String {
        val clean = input.trim().lowercase()
        return if (clean.contains("@")) clean else "$clean@dolia.ai"
    }

    private fun resolveUsername(input: String): String {
        val clean = input.trim()
        return if (clean.contains("@")) clean.substringBefore("@") else clean
    }


    private fun applyProfile(
        config: SupabaseConfig,
        accessToken: String,
        userId: String,
        initialRole: UserRole,
        initialUsername: String,
        initialStudioId: String?
    ): Triple<UserRole, String, String?> {
        var role = initialRole
        var username = initialUsername
        var studioId = initialStudioId

        // DOLIA's canonical schema uses public.profiles. The Controller's
        // studio pairing is carried in Auth user_metadata as studio_user_id.
        val tables = listOf("profiles")
        for (table in tables) {
            try {
                val request = Request.Builder()
                    .url("${config.restUrl}/$table?id=eq.$userId&select=*")
                    .header("apikey", config.anonKey)
                    .header("Authorization", "Bearer $accessToken")
                    .get()
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val arr = JSONArray(response.body?.string().orEmpty())
                        if (arr.length() > 0) {
                            val item = arr.getJSONObject(0)
                            if (item.has("role")) role = UserRole.fromString(item.optString("role", role.value))
                            if (item.optString("username", "").isNotBlank()) username = item.optString("username")
                            val dbStudioId = item.optString("studio_id", "").takeIf { it.isNotBlank() }
                            if (dbStudioId != null) studioId = dbStudioId
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Profile lookup $table failed: ${e.message}")
            }
        }

        return Triple(role, username, studioId)
    }

    suspend fun login(
        config: SupabaseConfig,
        usernameOrEmail: String,
        password: String
    ): Result<SupabaseAuthResult> = withContext(Dispatchers.IO) {
        try {
            val email = resolveEmail(usernameOrEmail)
            val url = "${config.authUrl}/token?grant_type=password"
            val payload = JSONObject().apply {
                put("email", email)
                put("password", password)
            }.toString()

            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val rawError = parseSupabaseErrorMessage(body, "Login gagal (${response.code})")
                    val errorDesc = when {
                        rawError.contains("email rate", ignoreCase = true) || rawError.contains("rate limit", ignoreCase = true) || response.code == 429 ->
                            "Terlalu banyak permintaan autentikasi. Tunggu sebentar lalu coba login kembali. Login tidak lagi mencoba membuat akun otomatis."
                        rawError.contains("email not confirmed", ignoreCase = true) ->
                            "Login ditolak oleh Supabase karena email akun belum dikonfirmasi. Akun DOLIA internal harus ditandai confirmed di Supabase Auth; login tidak mengirim email."
                        else -> rawError
                    }
                    return@withContext Result.failure(IOException(errorDesc))
                }

                val json = JSONObject(body)
                val accessToken = json.getString("access_token")
                val refreshToken = json.optString("refresh_token", "")
                val userObj = json.getJSONObject("user")
                val userId = userObj.getString("id")
                val userEmail = userObj.optString("email", email)
                val userMeta = userObj.optJSONObject("user_metadata")
                val studioId = userMeta?.optString("studio_user_id", "")?.takeIf { it.isNotBlank() }

                val userMetaRole = if (userMeta != null && userMeta.has("role")) userMeta.optString("role") else null
                var resolvedRole = when {
                    userMetaRole != null -> UserRole.fromString(userMetaRole)
                    email.contains("mdqputra", ignoreCase = true) || email.contains("dolia", ignoreCase = true) -> UserRole.DOLIA
                    email.contains("mdqp02", ignoreCase = true) || email.contains("controller", ignoreCase = true) -> UserRole.CONTROLLER
                    else -> UserRole.CONTROLLER
                }
                var resolvedUsername = userMeta?.optString("username", resolveUsername(usernameOrEmail)) ?: resolveUsername(usernameOrEmail)

                val resolved = applyProfile(
                    config = config,
                    accessToken = accessToken,
                    userId = userId,
                    initialRole = resolvedRole,
                    initialUsername = resolvedUsername,
                    initialStudioId = studioId
                )
                resolvedRole = resolved.first
                resolvedUsername = resolved.second
                val resolvedStudioId = resolved.third

                val authUser = AuthUser(
                    id = userId,
                    username = resolvedUsername,
                    email = userEmail,
                    role = resolvedRole,
                    studioId = resolvedStudioId
                )

                Result.success(SupabaseAuthResult(accessToken, refreshToken, authUser))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Login error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Refresh an existing Supabase session without sending any email.
     * This is used when the app starts again or an access token expires.
     */
    suspend fun refreshSession(
        config: SupabaseConfig,
        refreshToken: String
    ): Result<SupabaseAuthResult> = withContext(Dispatchers.IO) {
        try {
            if (refreshToken.isBlank()) {
                return@withContext Result.failure(IOException("Refresh token kosong"))
            }

            val url = "${config.authUrl}/token?grant_type=refresh_token"
            val payload = JSONObject().apply {
                put("refresh_token", refreshToken)
            }.toString()

            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val rawError = parseSupabaseErrorMessage(body, "Sesi tidak dapat diperbarui (${response.code})")
                    return@withContext Result.failure(IOException(rawError))
                }

                val json = JSONObject(body)
                val accessToken = json.getString("access_token")
                val newRefreshToken = json.optString("refresh_token", refreshToken)
                val userObj = json.getJSONObject("user")
                val userId = userObj.getString("id")
                val userEmail = userObj.optString("email", "")
                val userMeta = userObj.optJSONObject("user_metadata")
                val studioId = userMeta?.optString("studio_user_id", "")?.takeIf { it.isNotBlank() }
                val userMetaRole = userMeta?.optString("role", null)
                var resolvedRole = userMetaRole?.let { UserRole.fromString(it) } ?: UserRole.CONTROLLER
                var resolvedUsername = userMeta?.optString("username", userEmail.substringBefore("@"))
                    ?: userEmail.substringBefore("@")

                val resolved = applyProfile(
                    config = config,
                    accessToken = accessToken,
                    userId = userId,
                    initialRole = resolvedRole,
                    initialUsername = resolvedUsername,
                    initialStudioId = studioId
                )
                resolvedRole = resolved.first
                resolvedUsername = resolved.second
                val resolvedStudioId = resolved.third

                Result.success(
                    SupabaseAuthResult(
                        accessToken = accessToken,
                        refreshToken = newRefreshToken,
                        user = AuthUser(
                            id = userId,
                            username = resolvedUsername,
                            email = userEmail,
                            role = resolvedRole,
                            studioId = resolvedStudioId
                        )
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Refresh session error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun register(
        config: SupabaseConfig,
        usernameOrEmail: String,
        password: String,
        role: UserRole,
        studioUserId: String? = null
    ): Result<SupabaseAuthResult> = withContext(Dispatchers.IO) {
        try {
            val email = resolveEmail(usernameOrEmail)
            val username = resolveUsername(usernameOrEmail)
            val url = "${config.authUrl}/signup"
            val payload = JSONObject().apply {
                put("email", email)
                put("password", password)
                put("data", JSONObject().apply {
                    put("username", username)
                    put("role", role.value)
                    if (!studioUserId.isNullOrBlank()) put("studio_user_id", studioUserId)
                })
            }.toString()

            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val rawError = parseSupabaseErrorMessage(body, "Registrasi gagal (${response.code})")
                    val errorDesc = when {
                        rawError.contains("email rate", ignoreCase = true) || rawError.contains("rate limit", ignoreCase = true) || response.code == 429 ->
                            "Supabase menolak pendaftaran karena rate limit email. Login DOLIA tidak menggunakan jalur email."
                        rawError.contains("email not confirmed", ignoreCase = true) ->
                            "Akun belum diaktifkan di Supabase Auth. Login DOLIA tetap password-only dan tidak mengirim email."
                        else -> rawError
                    }
                    return@withContext Result.failure(IOException(errorDesc))
                }

                val json = JSONObject(body)
                val accessToken = json.optString("access_token", "")
                val refreshToken = json.optString("refresh_token", "")
                val userObj = json.optJSONObject("user") ?: json
                val userId = userObj.optString("id", "")

                // If signup did not return access_token directly (e.g. requires sign-in), try logging in
                if (accessToken.isEmpty()) {
                    val loginRes = login(config, email, password)
                    if (loginRes.isSuccess) {
                        return@withContext loginRes
                    }
                }

                // Ensure profile is recorded in PostgreSQL profiles table
                if (accessToken.isNotEmpty() && userId.isNotEmpty()) {
                    try {
                        val profilePayload = JSONObject().apply {
                            put("id", userId)
                            put("username", username)
                            put("role", role.value)
                        }.toString()

                        val insertProfile = Request.Builder()
                            .url("${config.restUrl}/profiles")
                            .header("apikey", config.anonKey)
                            .header("Authorization", "Bearer $accessToken")
                            .header("Prefer", "resolution=merge-duplicates")
                            .post(profilePayload.toRequestBody(jsonMediaType))
                            .build()

                        client.newCall(insertProfile).execute().close()
                    } catch (e: Exception) {
                        Log.w(TAG, "Profile upsert note: ${e.message}")
                    }
                }

                val authUser = AuthUser(
                    id = userId,
                    username = username,
                    email = email,
                    role = role,
                    studioId = studioUserId
                )

                Result.success(SupabaseAuthResult(accessToken, refreshToken, authUser))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Register error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /** Pair an already-created Controller account with this Dolia Studio without sending email. */
    suspend fun pairControllerToStudio(
        config: SupabaseConfig,
        accessToken: String,
        studioUserId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("data", JSONObject().apply {
                    put("role", UserRole.CONTROLLER.value)
                    put("studio_user_id", studioUserId)
                })
            }.toString()
            val request = Request.Builder()
                .url("${config.authUrl}/user")
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $accessToken")
                .header("Content-Type", "application/json")
                .put(payload.toRequestBody(jsonMediaType))
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException(parseSupabaseErrorMessage(body, "Akun Controller tidak dapat dipasangkan ke Studio")))
                }
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseSupabaseErrorMessage(body: String, defaultMsg: String): String {
        return try {
            val errObj = JSONObject(body)
            when {
                errObj.has("error_description") && errObj.getString("error_description").isNotBlank() ->
                    errObj.getString("error_description")
                errObj.has("message") && errObj.getString("message").isNotBlank() ->
                    errObj.getString("message")
                errObj.has("msg") && errObj.getString("msg").isNotBlank() ->
                    errObj.getString("msg")
                errObj.has("error") && errObj.getString("error").isNotBlank() ->
                    errObj.getString("error")
                else -> defaultMsg
            }
        } catch (e: Exception) {
            defaultMsg
        }
    }
}
