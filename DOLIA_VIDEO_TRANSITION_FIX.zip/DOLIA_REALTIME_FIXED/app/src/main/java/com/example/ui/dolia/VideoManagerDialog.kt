package com.example.ui.dolia

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DoliaVideoItem
import com.example.data.model.VideoCategory
import com.example.ui.MainViewModel
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonYellow
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.DecimalFormat

@Composable
fun VideoManagerDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val videos by viewModel.videos.collectAsState()
    val isLoading by viewModel.videoLoading.collectAsState()
    val uploadProgress by viewModel.videoUploadProgress.collectAsState()
    val errorMsg by viewModel.videoErrorMessage.collectAsState()
    val successMsg by viewModel.videoSuccessMessage.collectAsState()
    val activeIdle by viewModel.activeIdleVideo.collectAsState()
    val activeSpeak by viewModel.activeSpeakVideo.collectAsState()

    var selectedCategory by remember { mutableStateOf(VideoCategory.IDLE) }
    var customName by remember { mutableStateOf("DOLIA_IDLE.mp4") }
    var uploadToCloud by remember { mutableStateOf(true) }

    // Android Zero-Permission Photo/Video Picker (Google Play Policy Compliant)
    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.uploadVideo(
                context = context,
                uri = uri,
                category = selectedCategory,
                customName = customName,
                uploadToCloud = uploadToCloud
            )
        }
    }

    // Android System File/Document Picker (Fallback for Downloads / SD Card files)
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.uploadVideo(
                context = context,
                uri = uri,
                category = selectedCategory,
                customName = customName,
                uploadToCloud = uploadToCloud
            )
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                .testTag("video_manager_dialog"),
            color = ObsidianSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(CyberCyan.copy(alpha = 0.15f))
                                .border(1.dp, CyberCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "VIDEO MANAGER DOLIA",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = TextPrimary
                            )
                            Text(
                                text = "Supabase Storage (dolia-videos) & PostgreSQL",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                    Row {
                        IconButton(
                            onClick = { viewModel.loadVideos() },
                            modifier = Modifier.testTag("refresh_videos_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = TextSecondary
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_video_manager_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Tutup",
                                tint = TextPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Success Message banner
                if (successMsg != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonGreen.copy(alpha = 0.15f))
                            .border(1.dp, NeonGreen.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = successMsg ?: "",
                            color = NeonGreen,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearVideoSuccess() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Dismiss success",
                                tint = NeonGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Error Message banner if any
                if (errorMsg != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonRed.copy(alpha = 0.15f))
                            .border(1.dp, NeonRed.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = errorMsg ?: "",
                            color = NeonRed,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearVideoError() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Dismiss error",
                                tint = NeonRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Upload Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianCard)
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "UPLOAD / SIMPAN VIDEO",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = CyberCyan
                        )

                        // Toggle destination: Cloud vs Local
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (uploadToCloud) CyberCyan.copy(alpha = 0.25f) else Color.Transparent)
                                    .border(1.dp, if (uploadToCloud) CyberCyan else ObsidianBorder, RoundedCornerShape(6.dp))
                                    .clickable { uploadToCloud = true }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Cloud + Auto Backup",
                                    fontSize = 10.sp,
                                    color = if (uploadToCloud) CyberCyan else TextSecondary,
                                    fontWeight = if (uploadToCloud) FontWeight.Bold else FontWeight.Normal
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (!uploadToCloud) NeonGreen.copy(alpha = 0.25f) else Color.Transparent)
                                    .border(1.dp, if (!uploadToCloud) NeonGreen else ObsidianBorder, RoundedCornerShape(6.dp))
                                    .clickable { uploadToCloud = false }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Lokal (Offline)",
                                    fontSize = 10.sp,
                                    color = if (!uploadToCloud) NeonGreen else TextSecondary,
                                    fontWeight = if (!uploadToCloud) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PresetChip(
                            label = "DOLIA_IDLE.mp4",
                            isSelected = selectedCategory == VideoCategory.IDLE && customName == "DOLIA_IDLE.mp4",
                            onClick = {
                                selectedCategory = VideoCategory.IDLE
                                customName = "DOLIA_IDLE.mp4"
                            }
                        )
                        PresetChip(
                            label = "DOLIA_SPEAK.mp4",
                            isSelected = selectedCategory == VideoCategory.SPEAK && customName == "DOLIA_SPEAK.mp4",
                            onClick = {
                                selectedCategory = VideoCategory.SPEAK
                                customName = "DOLIA_SPEAK.mp4"
                            }
                        )
                        PresetChip(
                            label = "REACTION",
                            isSelected = selectedCategory == VideoCategory.REACTION,
                            onClick = {
                                selectedCategory = VideoCategory.REACTION
                                customName = "REACTION_${System.currentTimeMillis()}.mp4"
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = customName,
                        onValueChange = { customName = it },
                        label = { Text("Nama File Video") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = ObsidianBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("video_name_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Action Pickers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Option 1: Photo/Video Picker (Zero-permission)
                        Button(
                            onClick = {
                                pickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            enabled = !isLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("pick_upload_video_button")
                        ) {
                            if (isLoading && uploadProgress != null) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color.Black,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Memproses...",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            } else {
                                Icon(
                                    Icons.Default.CloudUpload,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "PILIH DARI GALERI",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Option 2: Document / File Explorer Picker
                        OutlinedButton(
                            onClick = {
                                documentPickerLauncher.launch("video/*")
                            },
                            enabled = !isLoading,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("pick_document_video_button")
                        ) {
                            Icon(
                                Icons.Default.Movie,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "FILE / DOWNLOAD",
                                color = CyberCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (uploadProgress != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = uploadProgress ?: "",
                            fontSize = 11.sp,
                            color = NeonYellow,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // List of Available Videos
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "DAFTAR VIDEO TERSIMPAN (${videos.size})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        color = TextPrimary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        activeIdle?.let {
                            Text(
                                text = "IDLE: ${it.name}",
                                fontSize = 10.sp,
                                color = NeonGreen,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        activeSpeak?.let {
                            Text(
                                text = "SPEAK: ${it.name}",
                                fontSize = 10.sp,
                                color = NeonMagenta,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (videos.isEmpty() && !isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianCard)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(12.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.Movie,
                                contentDescription = null,
                                tint = TextSecondary.copy(alpha = 0.4f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Belum ada video tersimpan di Supabase Storage",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Upload DOLIA_IDLE.mp4 dan DOLIA_SPEAK.mp4 di atas.",
                                color = CyberCyan,
                                fontSize = 11.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .testTag("video_list"),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(videos, key = { it.id }) { video ->
                            VideoItemRow(
                                video = video,
                                onSetAsIdle = { viewModel.setActiveVideo(video.id, setAsIdle = true, setAsSpeak = false) },
                                onSetAsSpeak = { viewModel.setActiveVideo(video.id, setAsIdle = false, setAsSpeak = true) },
                                onDelete = { viewModel.deleteVideo(video.id, video.storagePath) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PresetChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) CyberCyan else ObsidianBorder
    val bg = if (isSelected) CyberCyan.copy(alpha = 0.15f) else ObsidianCard
    val textColor = if (isSelected) CyberCyan else TextSecondary

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = textColor
        )
    }
}

@Composable
fun VideoItemRow(
    video: DoliaVideoItem,
    onSetAsIdle: () -> Unit,
    onSetAsSpeak: () -> Unit,
    onDelete: () -> Unit
) {
    val formatSize = remember(video.sizeBytes) {
        if (video.sizeBytes <= 0) ""
        else {
            val mb = video.sizeBytes.toDouble() / (1024 * 1024)
            DecimalFormat("#.## MB").format(mb)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCard)
            .border(
                1.dp,
                if (video.isActiveIdle) NeonGreen.copy(alpha = 0.6f)
                else if (video.isActiveSpeak) NeonMagenta.copy(alpha = 0.6f)
                else ObsidianBorder,
                RoundedCornerShape(10.dp)
            )
            .padding(12.dp)
            .testTag("video_row_${video.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Movie,
                    contentDescription = null,
                    tint = if (video.isActiveIdle) NeonGreen else if (video.isActiveSpeak) NeonMagenta else CyberCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = video.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = video.category.label,
                            fontSize = 10.sp,
                            color = CyberCyan,
                            fontFamily = FontFamily.Monospace
                        )
                        if (formatSize.isNotEmpty()) {
                            Text(
                                text = " • $formatSize",
                                fontSize = 10.sp,
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Delete button
            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("delete_video_${video.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Hapus",
                    tint = NeonRed.copy(alpha = 0.8f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Active indicators and selection buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Status badges
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (video.isActiveIdle) {
                    StatusBadge(label = "AKTIF: IDLE", color = NeonGreen)
                }
                if (video.isActiveSpeak) {
                    StatusBadge(label = "AKTIF: SPEAK", color = NeonMagenta)
                }
            }

            // Selection buttons
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onSetAsIdle,
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (video.isActiveIdle) NeonGreen.copy(alpha = 0.2f) else Color.Transparent
                    ),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("set_idle_${video.id}")
                ) {
                    if (video.isActiveIdle) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = if (video.isActiveIdle) "IDLE AKTIF" else "Pilih IDLE",
                        color = if (video.isActiveIdle) NeonGreen else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                OutlinedButton(
                    onClick = onSetAsSpeak,
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (video.isActiveSpeak) NeonMagenta.copy(alpha = 0.2f) else Color.Transparent
                    ),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("set_speak_${video.id}")
                ) {
                    if (video.isActiveSpeak) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = NeonMagenta, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = if (video.isActiveSpeak) "SPEAK AKTIF" else "Pilih SPEAK",
                        color = if (video.isActiveSpeak) NeonMagenta else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBadge(label: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Icon(Icons.Default.Star, contentDescription = null, tint = color, modifier = Modifier.size(10.dp))
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = label,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
