package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AuthUser
import com.example.data.model.SessionData
import com.example.data.model.UserRole
import com.example.data.supabase.SupabaseConfig

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREF_NAME = "dolia_session_pref"
        private const val KEY_TOKEN = "key_token"
        private const val KEY_REFRESH_TOKEN = "key_refresh_token"
        private const val KEY_USER_ID = "key_user_id"
        private const val KEY_USERNAME = "key_username"
        private const val KEY_EMAIL = "key_email"
        private const val KEY_ROLE = "key_role"
        private const val KEY_STUDIO_ID = "key_studio_id"
        private const val KEY_SUPABASE_URL = "key_supabase_url"
        private const val KEY_SUPABASE_ANON_KEY = "key_supabase_anon_key"
    }

    fun getSupabaseConfig(): SupabaseConfig {
        // Supabase endpoint and anon key are application build configuration.
        // They are intentionally not read from device-entered settings so a newly
        // installed APK never asks the user to configure the backend.
        return SupabaseConfig.fromBuildConfig()
    }

    fun saveSupabaseConfig(url: String, anonKey: String? = null) {
        val editor = prefs.edit().putString(KEY_SUPABASE_URL, url.trim().trimEnd('/'))
        if (!anonKey.isNullOrBlank()) {
            editor.putString(KEY_SUPABASE_ANON_KEY, anonKey.trim())
        }
        editor.apply()
    }

    fun saveSession(
        token: String,
        refreshToken: String = "",
        user: AuthUser,
        serverUrl: String
    ) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_REFRESH_TOKEN, refreshToken)
            .putString(KEY_USER_ID, user.id)
            .putString(KEY_USERNAME, user.username)
            .putString(KEY_EMAIL, user.email)
            .putString(KEY_ROLE, user.role.value)
            .putString(KEY_STUDIO_ID, user.studioId ?: "")
            .putString(KEY_SUPABASE_URL, serverUrl.trimEnd('/'))
            .apply()
    }

    fun getSession(): SessionData? {
        val token = prefs.getString(KEY_TOKEN, null) ?: return null
        val refreshToken = prefs.getString(KEY_REFRESH_TOKEN, "") ?: ""
        val id = prefs.getString(KEY_USER_ID, null) ?: return null
        val username = prefs.getString(KEY_USERNAME, null) ?: return null
        val email = prefs.getString(KEY_EMAIL, "") ?: ""
        val roleStr = prefs.getString(KEY_ROLE, "controller")
        val studioId = prefs.getString(KEY_STUDIO_ID, "")?.takeIf { !it.isNullOrBlank() }
        val config = getSupabaseConfig()
        val role = UserRole.fromString(roleStr)
        val user = AuthUser(id = id, username = username, email = email, role = role, studioId = studioId)
        return SessionData(token = token, refreshToken = refreshToken, user = user, serverUrl = config.cleanUrl)
    }

    fun getServerUrl(): String {
        return getSupabaseConfig().cleanUrl
    }

    fun saveServerUrl(url: String) {
        saveSupabaseConfig(url)
    }

    fun clearSession() {
        val currentUrl = prefs.getString(KEY_SUPABASE_URL, null)
        val currentKey = prefs.getString(KEY_SUPABASE_ANON_KEY, null)
        prefs.edit()
            .remove(KEY_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_USER_ID)
            .remove(KEY_USERNAME)
            .remove(KEY_EMAIL)
            .remove(KEY_ROLE)
            .remove(KEY_STUDIO_ID)
            .apply()
        if (currentUrl != null) prefs.edit().putString(KEY_SUPABASE_URL, currentUrl).apply()
        if (currentKey != null) prefs.edit().putString(KEY_SUPABASE_ANON_KEY, currentKey).apply()
    }
}
