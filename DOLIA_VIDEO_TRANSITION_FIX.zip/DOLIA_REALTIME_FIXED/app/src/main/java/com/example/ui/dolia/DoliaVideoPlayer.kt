package com.example.ui.dolia

import android.net.Uri
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

/**
 * Seamless-ish double-buffered VideoView player.
 *
 * The next clip is prepared on the hidden VideoView while the current clip
 * remains visible. The visible player is switched only after the next clip is
 * prepared, avoiding the old visible blank/frozen frame between IDLE -> SPEAK
 * and SPEAK/REACTION -> IDLE transitions.
 */
private class DualVideoController(
    private val container: FrameLayout,
    private val onPlaybackError: ((String) -> Unit)?,
    private val onVideoEnded: (() -> Unit)?
) {
    private data class Slot(
        val view: VideoView,
        var url: String? = null,
        var prepared: Boolean = false,
        var requestedToken: Long = 0L
    )

    private val slots: List<Slot>
    private var activeIndex = 0
    private var requestToken = 0L
    private var disposed = false

    init {
        val first = VideoView(container.context)
        val second = VideoView(container.context)
        listOf(first, second).forEach { view ->
            view.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            view.visibility = View.INVISIBLE
            container.addView(view)
        }
        slots = listOf(Slot(first), Slot(second))
        slots[activeIndex].view.visibility = View.VISIBLE

        slots.forEachIndexed { index, slot ->
            slot.view.setOnCompletionListener {
                if (!disposed && index == activeIndex) {
                    onVideoEnded?.invoke()
                }
            }
            slot.view.setOnErrorListener { _, what, _ ->
                if (!disposed && index == activeIndex) {
                    Log.w(TAG, "Playback error what=$what")
                    onPlaybackError?.invoke("Gagal memuat video ($what)")
                }
                true
            }
        }
    }

    fun play(url: String?, isLooping: Boolean) {
        if (disposed) return
        if (url.isNullOrBlank()) {
            slots.forEach { it.view.stopPlayback(); it.view.visibility = View.INVISIBLE; it.url = null; it.prepared = false }
            return
        }

        val active = slots[activeIndex]
        if (active.url == url && active.prepared) {
            configureAndResume(active.view, isLooping)
            active.view.visibility = View.VISIBLE
            return
        }

        // Reuse a prepared slot immediately (important for SPEAK -> IDLE).
        val preparedIndex = slots.indexOfFirst { it.url == url && it.prepared }
        if (preparedIndex >= 0) {
            switchTo(preparedIndex, isLooping)
            return
        }

        val targetIndex = 1 - activeIndex
        val target = slots[targetIndex]
        val token = ++requestToken
        target.requestedToken = token
        target.url = url
        target.prepared = false

        try {
            target.view.visibility = View.INVISIBLE
            target.view.stopPlayback()
            target.view.setOnPreparedListener { mp ->
                if (disposed || target.requestedToken != token || target.url != url) return@setOnPreparedListener
                target.prepared = true
                mp.isLooping = isLooping
                mp.setVolume(1f, 1f)
                // Switch only once the target is actually prepared.
                switchTo(targetIndex, isLooping)
            }
            val uri = if (url.startsWith("/")) Uri.fromFile(File(url)) else Uri.parse(url)
            target.view.setVideoURI(uri)
        } catch (e: Exception) {
            Log.e(TAG, "Error setting video URI", e)
            onPlaybackError?.invoke(e.message ?: "Playback error")
        }
    }

    private fun switchTo(index: Int, isLooping: Boolean) {
        if (disposed || index !in slots.indices) return
        val oldIndex = activeIndex
        val old = slots[oldIndex]
        val next = slots[index]

        try {
            if (oldIndex != index) {
                old.view.pause()
            }
        } catch (_: Exception) {
        }

        activeIndex = index
        configureAndResume(next.view, isLooping)
        next.view.visibility = View.VISIBLE
        next.view.bringToFront()

        if (oldIndex != index) {
            old.view.visibility = View.INVISIBLE
        }
    }

    private fun configureAndResume(view: VideoView, isLooping: Boolean) {
        try {
            view.setOnPreparedListener { mp ->
                mp.isLooping = isLooping
                mp.setVolume(1f, 1f)
                view.start()
            }
            // A prepared VideoView can be resumed directly. Keeping the
            // listener also covers a player that is finishing preparation.
            view.start()
        } catch (e: Exception) {
            Log.e(TAG, "Error resuming video", e)
            onPlaybackError?.invoke(e.message ?: "Playback error")
        }
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        slots.forEach { slot ->
            try {
                slot.view.stopPlayback()
                slot.view.setOnPreparedListener(null)
                slot.view.setOnCompletionListener(null)
                slot.view.setOnErrorListener(null)
            } catch (_: Exception) {
            }
        }
    }

    companion object {
        private const val TAG = "DoliaVideoPlayer"
    }
}

@Composable
fun DoliaVideoPlayer(
    videoUrl: String?,
    isLooping: Boolean,
    modifier: Modifier = Modifier,
    onPlaybackError: ((String) -> Unit)? = null,
    onVideoEnded: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val callbacks = rememberUpdatedCallbacks(onPlaybackError, onVideoEnded)
    val container = remember {
        FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }
    val controller = remember(container) {
        DualVideoController(
            container = container,
            onPlaybackError = { callbacks.first(it) },
            onVideoEnded = { callbacks.second() }
        )
    }

    DisposableEffect(controller) {
        onDispose { controller.dispose() }
    }

    LaunchedEffect(videoUrl, isLooping) {
        controller.play(videoUrl, isLooping)
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { container },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun rememberUpdatedCallbacks(
    onPlaybackError: ((String) -> Unit)?,
    onVideoEnded: (() -> Unit)?
): Pair<(String) -> Unit, () -> Unit> {
    val latestError = androidx.compose.runtime.rememberUpdatedState(onPlaybackError)
    val latestEnded = androidx.compose.runtime.rememberUpdatedState(onVideoEnded)
    return remember {
        ({ message -> latestError.value?.invoke(message) }) to
            ({ latestEnded.value?.invoke() })
    }
}
