package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DoliaDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color.Black,
    primaryContainer = CyberCyanDim,
    onPrimaryContainer = TextPrimary,
    secondary = ElectricViolet,
    onSecondary = Color.White,
    secondaryContainer = ElectricVioletDim,
    onSecondaryContainer = TextPrimary,
    tertiary = NeonGreen,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = TextSecondary,
    outline = ObsidianBorder,
    error = NeonRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    // Always use the tailored Dolia Dark Futuristic theme for AI entertainer aesthetic
    MaterialTheme(
        colorScheme = DoliaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
