package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.model.DoliaVideoItem
import com.example.data.model.VideoCategory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class LocalVideoManager(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    private val videosDir: File = File(context.filesDir, "dolia_videos").apply {
        if (!exists()) mkdirs()
    }

    companion object {
        private const val TAG = "LocalVideoManager"
        private const val PREF_NAME = "dolia_local_videos_pref"
        private const val KEY_VIDEOS_JSON = "key_videos_json"
    }

    /**
     * Saves a video binary locally to internal storage from a File without loading into memory heap.
     */
    fun saveVideoFromFile(
        fileName: String,
        category: VideoCategory,
        sourceFile: File,
        setAsIdle: Boolean = false,
        setAsSpeak: Boolean = false
    ): DoliaVideoItem {
        val sanitizedName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val uniqueFileName = "${category.value}_${System.currentTimeMillis()}_$sanitizedName"
        val destFile = File(videosDir, uniqueFileName)
        sourceFile.copyTo(destFile, overwrite = true)

        val id = "local_vid_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(4)}"
        val currentList = getVideos().toMutableList()

        val willBeIdle = setAsIdle || (category == VideoCategory.IDLE && currentList.none { it.isActiveIdle })
        val willBeSpeak = setAsSpeak || (category == VideoCategory.SPEAK && currentList.none { it.isActiveSpeak })

        val updatedList = currentList.map { item ->
            item.copy(
                isActiveIdle = if (willBeIdle) false else item.isActiveIdle,
                isActiveSpeak = if (willBeSpeak) false else item.isActiveSpeak
            )
        }.toMutableList()

        val newItem = DoliaVideoItem(
            id = id,
            name = fileName,
            category = category,
            url = destFile.absolutePath,
            storagePath = destFile.name,
            sizeBytes = destFile.length(),
            isActiveIdle = willBeIdle,
            isActiveSpeak = willBeSpeak,
            createdAt = System.currentTimeMillis()
        )

        updatedList.add(0, newItem)
        saveList(updatedList)
        Log.d(TAG, "Saved local video from file ${newItem.name} -> ${destFile.absolutePath}")
        return newItem
    }

    /**
     * Saves a video binary locally to internal storage and registers it in SharedPreferences.
     */
    fun saveVideo(
        fileName: String,
        category: VideoCategory,
        bytes: ByteArray,
        setAsIdle: Boolean = false,
        setAsSpeak: Boolean = false
    ): DoliaVideoItem {
        val sanitizedName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val uniqueFileName = "${category.value}_${System.currentTimeMillis()}_$sanitizedName"
        val destFile = File(videosDir, uniqueFileName)
        destFile.writeBytes(bytes)

        val id = "local_vid_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(4)}"
        val currentList = getVideos().toMutableList()

        val willBeIdle = setAsIdle || (category == VideoCategory.IDLE && currentList.none { it.isActiveIdle })
        val willBeSpeak = setAsSpeak || (category == VideoCategory.SPEAK && currentList.none { it.isActiveSpeak })

        val updatedList = currentList.map { item ->
            item.copy(
                isActiveIdle = if (willBeIdle) false else item.isActiveIdle,
                isActiveSpeak = if (willBeSpeak) false else item.isActiveSpeak
            )
        }.toMutableList()

        val newItem = DoliaVideoItem(
            id = id,
            name = fileName,
            category = category,
            url = destFile.absolutePath,
            storagePath = destFile.name,
            sizeBytes = bytes.size.toLong(),
            isActiveIdle = willBeIdle,
            isActiveSpeak = willBeSpeak,
            createdAt = System.currentTimeMillis()
        )

        updatedList.add(0, newItem)
        saveList(updatedList)
        Log.d(TAG, "Saved local video ${newItem.name} -> ${destFile.absolutePath}")
        return newItem
    }

    /**
     * Retrieves all locally saved videos.
     */
    fun getVideos(): List<DoliaVideoItem> {
        val jsonStr = prefs.getString(KEY_VIDEOS_JSON, null) ?: return emptyList()
        val list = mutableListOf<DoliaVideoItem>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val filePath = obj.optString("url", "")
                // Verify file still exists on disk
                val file = File(filePath)
                if (file.exists() && file.length() > 0) {
                    list.add(
                        DoliaVideoItem(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            category = VideoCategory.fromString(obj.optString("category", "idle")),
                            url = filePath,
                            storagePath = obj.optString("storage_path", file.name),
                            sizeBytes = obj.optLong("size_bytes", file.length()),
                            isActiveIdle = obj.optBoolean("is_active_idle", false),
                            isActiveSpeak = obj.optBoolean("is_active_speak", false),
                            createdAt = obj.optLong("created_at", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse local videos JSON: ${e.message}")
        }
        return list
    }

    /**
     * Sets a video as active IDLE or active SPEAK.
     */
    fun setActive(videoId: String, setAsIdle: Boolean, setAsSpeak: Boolean): List<DoliaVideoItem> {
        val list = getVideos().map { item ->
            if (item.id == videoId) {
                item.copy(
                    isActiveIdle = if (setAsIdle) true else item.isActiveIdle,
                    isActiveSpeak = if (setAsSpeak) true else item.isActiveSpeak
                )
            } else {
                item.copy(
                    isActiveIdle = if (setAsIdle) false else item.isActiveIdle,
                    isActiveSpeak = if (setAsSpeak) false else item.isActiveSpeak
                )
            }
        }
        saveList(list)
        return list
    }

    /**
     * Deletes a local video file and its metadata.
     */
    fun deleteVideo(videoId: String): List<DoliaVideoItem> {
        val list = getVideos()
        val target = list.firstOrNull { it.id == videoId }
        if (target != null) {
            try {
                val f = File(target.url)
                if (f.exists()) f.delete()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to delete file: ${e.message}")
            }
        }
        val remaining = list.filterNot { it.id == videoId }
        saveList(remaining)
        return remaining
    }

    private fun saveList(list: List<DoliaVideoItem>) {
        try {
            val arr = JSONArray()
            for (item in list) {
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("category", item.category.value)
                    put("url", item.url)
                    put("storage_path", item.storagePath)
                    put("size_bytes", item.sizeBytes)
                    put("is_active_idle", item.isActiveIdle)
                    put("is_active_speak", item.isActiveSpeak)
                    put("created_at", item.createdAt)
                }
                arr.put(obj)
            }
            prefs.edit().putString(KEY_VIDEOS_JSON, arr.toString()).apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save local videos: ${e.message}")
        }
    }
}
