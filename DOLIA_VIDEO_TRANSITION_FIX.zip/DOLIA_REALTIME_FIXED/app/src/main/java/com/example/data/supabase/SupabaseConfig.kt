package com.example.data.supabase

import com.example.BuildConfig

data class SupabaseConfig(
    val url: String,
    val anonKey: String
) {
    val cleanUrl: String
        get() {
            var u = url.trim()
            if (!u.startsWith("http://") && !u.startsWith("https://") && u.isNotEmpty() && !u.startsWith("your-project")) {
                u = "https://$u"
            }
            return u.trimEnd('/')
                .removeSuffix("/rest/v1")
                .removeSuffix("/auth/v1")
                .removeSuffix("/realtime/v1")
        }

    val cleanAnonKey: String
        get() = anonKey.trim()

    val authUrl: String
        get() = "$cleanUrl/auth/v1"

    val restUrl: String
        get() = "$cleanUrl/rest/v1"

    val realtimeWsUrl: String
        get() {
            val host = cleanUrl
                .removePrefix("https://")
                .removePrefix("http://")
                .trimEnd('/')
            return "wss://$host/realtime/v1/websocket?apikey=$cleanAnonKey&vsn=1.0.0"
        }

    companion object {
        fun fromBuildConfig(): SupabaseConfig {
            val buildUrl = BuildConfig.SUPABASE_URL.trim()
            val buildKey = BuildConfig.SUPABASE_ANON_KEY.trim()
            return SupabaseConfig(url = buildUrl, anonKey = buildKey)
        }
    }
}
