package com.example.data.model

enum class UserRole(val value: String) {
    CONTROLLER("controller"),
    DOLIA("dolia");

    companion object {
        fun fromString(value: String?): UserRole {
            return when (value?.lowercase()?.trim()) {
                "dolia" -> DOLIA
                else -> CONTROLLER
            }
        }
    }
}

data class AuthUser(
    val id: String,
    val username: String,
    val email: String,
    val role: UserRole,
    /** Supabase user id of the Dolia Studio this account is paired to. */
    val studioId: String? = null
)

data class SessionData(
    val token: String,
    val refreshToken: String = "",
    val user: AuthUser,
    val serverUrl: String
)

data class CommandHistoryItem(
    val id: String,
    val text: String,
    val timestamp: Long,
    val status: String,
    val doliaCount: Int = 0
)

enum class ConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}

enum class DoliaSpeechStatus {
    IDLE,
    SPEAKING
}

enum class VideoCategory(val value: String, val label: String) {
    IDLE("idle", "DOLIA_IDLE"),
    SPEAK("speak", "DOLIA_SPEAK"),
    REACTION("reaction", "REACTION");

    companion object {
        fun fromString(value: String?): VideoCategory {
            return when (value?.lowercase()?.trim()) {
                "speak" -> SPEAK
                "reaction" -> REACTION
                else -> IDLE
            }
        }
    }
}

data class DoliaVideoItem(
    val id: String,
    val name: String,
    val category: VideoCategory,
    val url: String,
    val storagePath: String,
    val sizeBytes: Long = 0,
    val isActiveIdle: Boolean = false,
    val isActiveSpeak: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
