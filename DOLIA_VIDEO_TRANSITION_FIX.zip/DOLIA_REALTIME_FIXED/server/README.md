# DOLIA Realtime Backend Server

Backend server untuk menghubungkan aplikasi **DOLIA Controller** dan **DOLIA Studio** secara realtime menggunakan Node.js, Express, dan WebSocket.

## Fitur Backend
1. **Authentication & Session**: Login & register dengan password hashing (`scrypt`) dan JSON Web Token (JWT).
2. **Role-Based Access Control (RBAC)**:
   - `controller`: Berhak mengirim command `{ type: "speak", text: "..." }`.
   - `dolia`: Menerima command realtime dan membroadcast status online/offline. Dilarang mengirim command.
3. **Realtime Command Delivery**: WebSocket endpoint `/ws?token=<jwt>` dengan dispatch cepat ke perangkat Dolia.
4. **Device Online/Offline Tracking**: Server mendeteksi saat perangkat Dolia terhubung atau terputus, dan otomatis memberi tahu Controller.
5. **Command Logging**: Riwayat perintah tersimpan dengan metadata pengirim dan status pengiriman.

## Akun Bawaan (Default Seed Accounts)
- **Controller**:
  - Username: `controller`
  - Password: `controller123`
  - Role: `controller`
- **Dolia Studio**:
  - Username: `dolia`
  - Password: `dolia123`
  - Role: `dolia`

## Cara Menjalankan Backend

### 1. Prasyarat
- Node.js versi 18 atau lebih baru.
- npm.

### 2. Instalasi Dependensi
Jalankan perintah berikut di dalam folder `server`:
```bash
cd server
npm install
```

### 3. Konfigurasi Environment (`.env`)
File `.env` sudah disediakan. Anda dapat menyesuaikan konfigurasi jika diperlukan:
```env
PORT=3000
JWT_SECRET=dolia_production_jwt_secret_key_77a942b0c3f54d19
NODE_ENV=production
```

### 4. Menjalankan Server
```bash
npm start
```
Server akan berjalan pada `http://localhost:3000` (atau IP lokal komputer Anda, misalnya `http://192.168.1.100:3000`).

### 5. Menghubungkan dari HP / Tablet (Redmi Pad)
- Pastikan HP/Tablet dan Komputer dapat saling mengakses (misalnya berada pada Wi-Fi yang sama, atau menggunakan VPS / Ngrok / Cloud Run jika melalui internet publik).
- Pada aplikasi Android DOLIA, buka ikon pengaturan Server di pojok kanan atas, lalu masukkan URL server Anda, contoh:
  `http://192.168.1.100:3000`
  (atau jika menggunakan emulator Android Studio: `http://10.0.2.2:3000`).
- Jika menggunakan Cloud / Ngrok:
  `https://your-domain.ngrok-free.app`
