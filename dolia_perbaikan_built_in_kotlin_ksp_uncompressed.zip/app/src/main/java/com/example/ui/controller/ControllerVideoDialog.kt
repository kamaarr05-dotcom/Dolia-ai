package com.example.ui.controller

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DoliaVideoItem
import com.example.data.model.VideoCategory
import com.example.ui.MainViewModel
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonRed
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ControllerVideoDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val videos by viewModel.videos.collectAsState()
    val loading by viewModel.videoLoading.collectAsState()
    val feedback by viewModel.lastSentFeedback.collectAsState()
    var selectedCategory by remember { mutableStateOf(VideoCategory.IDLE) }

    val filtered = remember(videos, selectedCategory) {
        videos.filter { it.category == selectedCategory }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianBg,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("KONTROL VIDEO DOLIA", fontWeight = FontWeight.Black, color = CyberCyan, fontSize = 18.sp)
                    Text("Pilih video → otomatis tampil di Studio", fontSize = 11.sp, color = TextSecondary)
                }
                Row {
                    IconButton(onClick = { viewModel.loadVideos() }, enabled = !loading, modifier = Modifier.testTag("controller_refresh_videos")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = CyberCyan)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("controller_close_video_dialog")) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextPrimary)
                    }
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CategoryButton("IDLE", VideoCategory.IDLE, selectedCategory, NeonGreen) { selectedCategory = it }
                    CategoryButton("REACTION", VideoCategory.REACTION, selectedCategory, ElectricViolet) { selectedCategory = it }
                    CategoryButton("SPEAK", VideoCategory.SPEAK, selectedCategory, NeonMagenta) { selectedCategory = it }
                }
                Spacer(modifier = Modifier.height(12.dp))

                if (loading) {
                    Box(modifier = Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                        Text("Memuat daftar video...", color = TextSecondary)
                    }
                } else if (filtered.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = TextMuted, modifier = Modifier.size(42.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Belum ada video ${selectedCategory.label}", color = TextSecondary)
                            Text("Upload video dari Dolia Studio terlebih dahulu.", color = TextMuted, fontSize = 11.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().height(360.dp).testTag("controller_video_list"),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filtered, key = { it.id }) { video ->
                            ControllerVideoRow(video = video) {
                                viewModel.selectVideoForDolia(video, selectedCategory)
                            }
                        }
                    }
                }

                if (!feedback.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    val isWarning = feedback!!.startsWith("⚠")
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = if (isWarning) NeonRed.copy(alpha = 0.14f) else NeonGreen.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isWarning) NeonRed.copy(alpha = 0.45f) else NeonGreen.copy(alpha = 0.45f))
                    ) {
                        Text(feedback!!, color = if (isWarning) NeonRed else NeonGreen, fontSize = 11.sp, modifier = Modifier.padding(10.dp))
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = CyberCyan), modifier = Modifier.testTag("controller_video_done_button")) {
                Text("SELESAI", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun CategoryButton(
    label: String,
    category: VideoCategory,
    selected: VideoCategory,
    color: Color,
    onSelect: (VideoCategory) -> Unit
) {
    val active = category == selected
    OutlinedButton(
        onClick = { onSelect(category) },
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = if (active) color.copy(alpha = 0.16f) else Color.Transparent)
    ) {
        Text(label, color = if (active) color else TextSecondary, fontSize = 10.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun ControllerVideoRow(video: DoliaVideoItem, onSelect: () -> Unit) {
    val categoryColor = when (video.category) {
        VideoCategory.IDLE -> NeonGreen
        VideoCategory.SPEAK -> NeonMagenta
        VideoCategory.REACTION -> ElectricViolet
    }
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(ObsidianCard).border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Movie, contentDescription = null, tint = categoryColor, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(9.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(video.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
            Text(video.category.label, color = categoryColor, fontSize = 10.sp)
        }
        Button(
            onClick = onSelect,
            colors = ButtonDefaults.buttonColors(containerColor = categoryColor.copy(alpha = 0.9f)),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp),
            modifier = Modifier.height(36.dp).testTag("controller_select_video_${video.id}")
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.Black, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("TAMPILKAN", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}
