package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Futuristic Cyber Theme Colors for DOLIA
val ObsidianBg = Color(0xFF090C10)
val ObsidianSurface = Color(0xFF101622)
val ObsidianCard = Color(0xFF161E2E)
val ObsidianBorder = Color(0xFF222D42)

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDim = Color(0xFF0091A1)
val ElectricViolet = Color(0xFFA855F7)
val ElectricVioletDim = Color(0xFF7E22CE)
val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF3366)
val NeonYellow = Color(0xFFFFD600)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
