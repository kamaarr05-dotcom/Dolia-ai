package com.example.data.supabase

import com.example.BuildConfig

data class SupabaseConfig(
    val url: String,
    val anonKey: String
) {
    val cleanUrl: String
        get() {
            var u = url.trim()
            if (!u.startsWith("http://") && !u.startsWith("https://") && u.isNotEmpty() && !u.startsWith("your-project")) {
                u = "https://$u"
            }
            return u.trimEnd('/')
                .removeSuffix("/rest/v1")
                .removeSuffix("/auth/v1")
                .removeSuffix("/realtime/v1")
        }

    val cleanAnonKey: String
        get() = anonKey.trim()

    val authUrl: String
        get() = "$cleanUrl/auth/v1"

    val restUrl: String
        get() = "$cleanUrl/rest/v1"

    val realtimeWsUrl: String
        get() {
            val host = cleanUrl
                .removePrefix("https://")
                .removePrefix("http://")
                .trimEnd('/')
            return "wss://$host/realtime/v1/websocket?apikey=$cleanAnonKey&vsn=1.0.0"
        }

    companion object {
        private const val FALLBACK_URL = "https://your-project.supabase.co"
        private const val FALLBACK_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.your-anon-key-placeholder"

        fun fromBuildConfig(): SupabaseConfig {
            val buildUrl = try {
                BuildConfig.SUPABASE_URL.takeIf { it.isNotBlank() } ?: FALLBACK_URL
            } catch (e: Throwable) {
                FALLBACK_URL
            }
            val buildKey = try {
                BuildConfig.SUPABASE_ANON_KEY.takeIf { it.isNotBlank() } ?: FALLBACK_ANON_KEY
            } catch (e: Throwable) {
                FALLBACK_ANON_KEY
            }
            return SupabaseConfig(url = buildUrl, anonKey = buildKey)
        }
    }
}
