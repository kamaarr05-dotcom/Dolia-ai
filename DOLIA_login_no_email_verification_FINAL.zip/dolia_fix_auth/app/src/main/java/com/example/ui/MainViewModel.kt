package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LocalVideoManager
import com.example.data.local.SessionManager
import com.example.data.model.AuthUser
import com.example.data.model.CommandHistoryItem
import com.example.data.model.ConnectionStatus
import com.example.data.model.DoliaSpeechStatus
import com.example.data.model.DoliaVideoItem
import com.example.data.model.SessionData
import com.example.data.model.UserRole
import com.example.data.model.VideoCategory
import com.example.data.supabase.SupabaseAuthClient
import com.example.data.supabase.SupabaseConfig
import com.example.data.supabase.SupabaseDatabaseClient
import com.example.data.supabase.SupabaseRealtimeClient
import com.example.data.supabase.SupabaseStorageClient
import com.example.tts.DoliaTtsEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {
    companion object {
        private const val TAG = "MainViewModel"
    }

    private val sessionManager = SessionManager(application)
    private val localVideoManager = LocalVideoManager(application)
    private val authClient = SupabaseAuthClient()
    private val databaseClient = SupabaseDatabaseClient()
    private val storageClient = SupabaseStorageClient()
    private val realtimeClient = SupabaseRealtimeClient(viewModelScope)
    val ttsEngine = DoliaTtsEngine(application, viewModelScope)

    // Current Session
    private val _session = MutableStateFlow<SessionData?>(null)
    val session: StateFlow<SessionData?> = _session.asStateFlow()

    // Supabase Config State
    private val _supabaseConfig = MutableStateFlow(sessionManager.getSupabaseConfig())
    val supabaseConfig: StateFlow<SupabaseConfig> = _supabaseConfig.asStateFlow()

    private val _serverUrl = MutableStateFlow(_supabaseConfig.value.cleanUrl)
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    // Auth Form State
    private val _username = MutableStateFlow("")
    val username: StateFlow<String> = _username.asStateFlow()

    private val _password = MutableStateFlow("")
    val password: StateFlow<String> = _password.asStateFlow()

    private val _selectedRole = MutableStateFlow(UserRole.CONTROLLER)
    val selectedRole: StateFlow<UserRole> = _selectedRole.asStateFlow()

    private val _isRegisterMode = MutableStateFlow(false)
    val isRegisterMode: StateFlow<Boolean> = _isRegisterMode.asStateFlow()

    private val _controllerRegistrationLoading = MutableStateFlow(false)
    val controllerRegistrationLoading: StateFlow<Boolean> = _controllerRegistrationLoading.asStateFlow()

    private val _controllerRegistrationMessage = MutableStateFlow<String?>(null)
    val controllerRegistrationMessage: StateFlow<String?> = _controllerRegistrationMessage.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    // Realtime States
    val connectionStatus: StateFlow<ConnectionStatus> = realtimeClient.connectionStatus
    val isDoliaOnline: StateFlow<Boolean> = realtimeClient.isDoliaOnline
    val doliaCount: StateFlow<Int> = realtimeClient.doliaCount

    // Controller Panel State
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _commandHistory = MutableStateFlow<List<CommandHistoryItem>>(emptyList())
    val commandHistory: StateFlow<List<CommandHistoryItem>> = _commandHistory.asStateFlow()

    private val _lastSentFeedback = MutableStateFlow<String?>(null)
    val lastSentFeedback: StateFlow<String?> = _lastSentFeedback.asStateFlow()

    // Dolia Studio State
    val speechStatus: StateFlow<DoliaSpeechStatus> = ttsEngine.speechStatus
    val currentSpokenText: StateFlow<String> = ttsEngine.currentSpokenText

    // Video Manager State (Dolia Studio only)
    private val _videos = MutableStateFlow<List<DoliaVideoItem>>(emptyList())
    val videos: StateFlow<List<DoliaVideoItem>> = _videos.asStateFlow()

    private val _activeIdleVideo = MutableStateFlow<DoliaVideoItem?>(null)
    val activeIdleVideo: StateFlow<DoliaVideoItem?> = _activeIdleVideo.asStateFlow()

    private val _activeSpeakVideo = MutableStateFlow<DoliaVideoItem?>(null)
    val activeSpeakVideo: StateFlow<DoliaVideoItem?> = _activeSpeakVideo.asStateFlow()

    private val _activeReactionVideo = MutableStateFlow<DoliaVideoItem?>(null)
    val activeReactionVideo: StateFlow<DoliaVideoItem?> = _activeReactionVideo.asStateFlow()

    // Video currently requested for display in Dolia Studio. This is deliberately
    // separate from the configured IDLE/SPEAK/REACTION videos so a Controller
    // selection takes effect immediately on the Studio device.
    private val _studioVideoMode = MutableStateFlow(VideoCategory.IDLE)
    val studioVideoMode: StateFlow<VideoCategory> = _studioVideoMode.asStateFlow()

    private val _videoLoading = MutableStateFlow(false)
    val videoLoading: StateFlow<Boolean> = _videoLoading.asStateFlow()

    private val _videoUploadProgress = MutableStateFlow<String?>(null)
    val videoUploadProgress: StateFlow<String?> = _videoUploadProgress.asStateFlow()

    private val _videoErrorMessage = MutableStateFlow<String?>(null)
    val videoErrorMessage: StateFlow<String?> = _videoErrorMessage.asStateFlow()

    private val _videoSuccessMessage = MutableStateFlow<String?>(null)
    val videoSuccessMessage: StateFlow<String?> = _videoSuccessMessage.asStateFlow()

    init {
        // Wire Realtime callbacks
        realtimeClient.onSpeakCommandReceived = { text, id ->
            if (_session.value?.user?.role == UserRole.DOLIA) {
                Log.d(TAG, "Dolia triggering local Android TTS for command: $id")
                ttsEngine.speak(text)
            }
        }

        realtimeClient.onSelectVideoCommandReceived = { videoId, videoUrl, videoName, catString ->
            if (_session.value?.user?.role == UserRole.DOLIA) {
                Log.d(TAG, "Dolia received Realtime select_video: $videoName ($catString)")
                val cat = VideoCategory.fromString(catString)
                when (catString) {
                    "clear_reaction" -> {
                        _activeReactionVideo.value = null
                        _studioVideoMode.value = VideoCategory.IDLE
                    }
                    else -> {
                        val videoItem = _videos.value.firstOrNull { it.id == videoId || it.url == videoUrl }
                            ?: DoliaVideoItem(
                                id = videoId,
                                name = videoName,
                                category = cat,
                                url = videoUrl,
                                storagePath = "",
                                isActiveIdle = cat == VideoCategory.IDLE,
                                isActiveSpeak = cat == VideoCategory.SPEAK
                            )

                        when (cat) {
                            VideoCategory.IDLE -> {
                                _studioVideoMode.value = VideoCategory.IDLE
                                _activeReactionVideo.value = null
                                _activeIdleVideo.value = videoItem
                                _videos.value = _videos.value.map {
                                    it.copy(isActiveIdle = (it.id == videoItem.id))
                                }
                                localVideoManager.setActive(videoItem.id, setAsIdle = true, setAsSpeak = false)
                            }
                            VideoCategory.SPEAK -> {
                                _studioVideoMode.value = VideoCategory.SPEAK
                                _activeSpeakVideo.value = videoItem
                                _videos.value = _videos.value.map {
                                    it.copy(isActiveSpeak = (it.id == videoItem.id))
                                }
                                localVideoManager.setActive(videoItem.id, setAsIdle = false, setAsSpeak = true)
                            }
                            VideoCategory.REACTION -> {
                                _studioVideoMode.value = VideoCategory.REACTION
                                _activeReactionVideo.value = videoItem
                            }
                        }
                    }
                }
            }
        }

        realtimeClient.onCommandAckReceived = { id, status, count ->
            _commandHistory.value = _commandHistory.value.map { item ->
                if (item.id == id) {
                    item.copy(
                        status = if (status == "delivered") "Delivered to Dolia" else "Queued (Dolia Offline)",
                        doliaCount = count
                    )
                } else item
            }
        }

        ttsEngine.onSpeechStatusChanged = { isSpeaking, text ->
            if (_session.value?.user?.role == UserRole.DOLIA) {
                if (isSpeaking && _activeSpeakVideo.value != null && _activeReactionVideo.value == null) {
                    _studioVideoMode.value = VideoCategory.SPEAK
                } else if (!isSpeaking && _activeReactionVideo.value == null) {
                    _studioVideoMode.value = VideoCategory.IDLE
                }
                realtimeClient.notifySpeechStatus(isSpeaking, text)
            }
        }

        realtimeClient.onAuthFailed = {
            viewModelScope.launch(Dispatchers.IO) {
                val current = _session.value
                if (current != null && current.refreshToken.isNotBlank()) {
                    val refreshed = authClient.refreshSession(_supabaseConfig.value, current.refreshToken)
                    refreshed.onSuccess { authResult ->
                        val updatedUser = authResult.user.copy(role = current.user.role)
                        val updatedSession = current.copy(
                            token = authResult.accessToken,
                            refreshToken = authResult.refreshToken,
                            user = updatedUser
                        )
                        sessionManager.saveSession(
                            token = updatedSession.token,
                            refreshToken = updatedSession.refreshToken,
                            user = updatedSession.user,
                            serverUrl = updatedSession.serverUrl
                        )
                        viewModelScope.launch(Dispatchers.Main) {
                            _session.value = updatedSession
                            connectRealtime(updatedSession)
                        }
                    }.onFailure {
                        viewModelScope.launch(Dispatchers.Main) {
                            _authError.value = "Sesi Supabase telah kedaluwarsa. Silakan login kembali."
                            logout()
                        }
                    }
                } else {
                    viewModelScope.launch(Dispatchers.Main) {
                        _authError.value = "Sesi Supabase telah kedaluwarsa. Silakan login kembali."
                        logout()
                    }
                }
            }
        }

        // Restore saved session. Refresh it first when a refresh token exists, so
        // reopening the app does not expose an expired access token as a dead session.
        val savedSession = sessionManager.getSession()
        if (savedSession != null) {
            viewModelScope.launch(Dispatchers.IO) {
                val refreshed = if (savedSession.refreshToken.isNotBlank()) {
                    authClient.refreshSession(_supabaseConfig.value, savedSession.refreshToken)
                } else {
                    Result.failure(IllegalStateException("Refresh token kosong"))
                }

                refreshed.onSuccess { authResult ->
                    val updatedUser = authResult.user.copy(role = savedSession.user.role)
                    val updatedSession = savedSession.copy(
                        token = authResult.accessToken,
                        refreshToken = authResult.refreshToken,
                        user = updatedUser
                    )
                    sessionManager.saveSession(
                        token = updatedSession.token,
                        refreshToken = updatedSession.refreshToken,
                        user = updatedSession.user,
                        serverUrl = updatedSession.serverUrl
                    )
                    viewModelScope.launch(Dispatchers.Main) {
                        _session.value = updatedSession
                        _serverUrl.value = updatedSession.serverUrl
                        connectRealtime(updatedSession)
                        if (updatedSession.user.role == UserRole.CONTROLLER) {
                            loadCommandHistory(updatedSession)
                            loadVideos(updatedSession)
                        } else if (updatedSession.user.role == UserRole.DOLIA) {
                            loadVideos(updatedSession)
                        }
                    }
                }.onFailure {
                    // Keep a still-valid saved access token usable when refresh is unavailable.
                    _session.value = savedSession
                    _serverUrl.value = savedSession.serverUrl
                    connectRealtime(savedSession)
                    if (savedSession.user.role == UserRole.CONTROLLER) {
                        loadCommandHistory(savedSession)
                        loadVideos(savedSession)
                    } else if (savedSession.user.role == UserRole.DOLIA) {
                        loadVideos(savedSession)
                    }
                }
            }
        }
    }

    fun updateUsername(v: String) { _username.value = v }
    fun updatePassword(v: String) { _password.value = v }
    fun updateRole(r: UserRole) { _selectedRole.value = r }

    fun toggleRegisterMode() {
        _isRegisterMode.value = !_isRegisterMode.value
        _authError.value = null
    }

    fun updateServerUrl(url: String, anonKey: String? = null) {
        val clean = url.trimEnd('/')
        sessionManager.saveSupabaseConfig(clean, anonKey)
        val updatedConfig = sessionManager.getSupabaseConfig()
        _supabaseConfig.value = updatedConfig
        _serverUrl.value = updatedConfig.cleanUrl

        _session.value?.let { current ->
            val updatedSession = current.copy(serverUrl = updatedConfig.cleanUrl)
            _session.value = updatedSession
            sessionManager.saveSession(
                token = updatedSession.token,
                refreshToken = updatedSession.refreshToken,
                user = updatedSession.user,
                serverUrl = updatedConfig.cleanUrl
            )
            connectRealtime(updatedSession)
            if (updatedSession.user.role == UserRole.DOLIA || updatedSession.user.role == UserRole.CONTROLLER) {
                loadVideos(updatedSession)
            }
        }
    }

    fun updateInputText(t: String) { _inputText.value = t }

    fun registerControllerAccount(email: String, password: String) {
        val studio = _session.value
        if (studio?.user?.role != UserRole.DOLIA) {
            _controllerRegistrationMessage.value = "Hanya akun DOLIA Studio yang dapat mendaftarkan Controller."
            return
        }
        val cleanEmail = email.trim()
        if (cleanEmail.isEmpty() || !cleanEmail.contains("@")) {
            _controllerRegistrationMessage.value = "Email Controller tidak valid."
            return
        }
        if (password.length < 6) {
            _controllerRegistrationMessage.value = "Password Controller minimal 6 karakter."
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _controllerRegistrationLoading.value = true
            _controllerRegistrationMessage.value = null
            val config = _supabaseConfig.value
            val studioId = studio.user.id

            // Existing account path: login only, then update metadata. No email is sent.
            val existingLogin = authClient.login(config, cleanEmail, password)
            if (existingLogin.isSuccess) {
                val authResult = existingLogin.getOrThrow()
                val paired = authClient.pairControllerToStudio(config, authResult.accessToken, studioId)
                if (paired.isSuccess) {
                    _controllerRegistrationMessage.value = "Akun Controller sudah ada dan sekarang berhasil dipasangkan ke DOLIA Studio ini. Login di perangkat Controller dengan akun tersebut."
                } else {
                    _controllerRegistrationMessage.value = paired.exceptionOrNull()?.message ?: "Akun ada, tetapi gagal memasangkan ke Studio."
                }
            } else {
                // New account path: signup once, with studio_user_id stored in Auth metadata.
                // This path does not run during normal login, so ordinary re-entry never sends email.
                val created = authClient.register(
                    config = config,
                    usernameOrEmail = cleanEmail,
                    password = password,
                    role = UserRole.CONTROLLER,
                    studioUserId = studioId
                )
                if (created.isSuccess) {
                    _controllerRegistrationMessage.value = "Akun Controller berhasil dibuat dan dipasangkan ke DOLIA Studio ini. Login di perangkat Controller dengan email dan password tersebut."
                } else {
                    val msg = created.exceptionOrNull()?.message.orEmpty()
                    _controllerRegistrationMessage.value = when {
                        msg.contains("rate", true) || msg.contains("limit", true) || msg.contains("429") ->
                            "Supabase masih membatasi signup/email. Matikan Authentication > Providers > Email > Confirm Email agar pembuatan akun internal tidak mengirim email."
                        msg.contains("already", true) || msg.contains("registered", true) || msg.contains("exists", true) ->
                            "Akun sudah ada. Login kembali dengan password yang benar; pendaftaran ulang tidak diperlukan."
                        else -> msg.ifBlank { "Gagal mendaftarkan Controller." }
                    }
                }
            }
            _controllerRegistrationLoading.value = false
        }
    }

    fun clearControllerRegistrationMessage() {
        _controllerRegistrationMessage.value = null
    }


    fun login() {
        val user = _username.value.trim()
        val pass = _password.value
        val config = _supabaseConfig.value

        if (user.isEmpty() || pass.isEmpty()) {
            _authError.value = "Username dan password tidak boleh kosong"
            return
        }

        if (config.url.contains("dummy.supabase.co") || config.url.contains("your-project.supabase.co")) {
            val role = if (user.contains("mdqputra", ignoreCase = true)) UserRole.DOLIA else _selectedRole.value
            val demoUser = AuthUser(
                id = if (role == UserRole.CONTROLLER) "ctrl-${user.substringBefore("@")}" else "dolia-${user.substringBefore("@")}",
                username = user.substringBefore("@"),
                email = if (user.contains("@")) user else "$user@dolia.ai",
                role = role
            )
            val demoSession = SessionData(
                token = "demo-offline-token",
                refreshToken = "demo-refresh-token",
                user = demoUser,
                serverUrl = config.cleanUrl
            )
            _session.value = demoSession
            _authLoading.value = false
            _authError.value = null

            if (role == UserRole.DOLIA) {
                loadVideos(demoSession)
            }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _authLoading.value = true
            _authError.value = null

            // LOGIN is password-only. It never calls signup, OTP, magic link, or resend.
            // This prevents ordinary re-entry from consuming Supabase email quota.
            val result = authClient.login(
                config = config,
                usernameOrEmail = user,
                password = pass
            )

            result.onSuccess { authResult ->
                val resolvedRole = when {
                    user.contains("mdqputra", ignoreCase = true) -> UserRole.DOLIA
                    user.contains("mdqp02", ignoreCase = true) -> UserRole.CONTROLLER
                    else -> authResult.user.role
                }
                val authUser = authResult.user.copy(role = resolvedRole)
                sessionManager.saveSession(
                    token = authResult.accessToken,
                    refreshToken = authResult.refreshToken,
                    user = authUser,
                    serverUrl = config.cleanUrl
                )
                val newSession = SessionData(
                    token = authResult.accessToken,
                    refreshToken = authResult.refreshToken,
                    user = authUser,
                    serverUrl = config.cleanUrl
                )
                _session.value = newSession
                _authLoading.value = false

                connectRealtime(newSession)

                // Update PostgreSQL device_status for Dolia or Controller
                databaseClient.upsertDeviceStatus(
                    config = config,
                    token = authResult.accessToken,
                    deviceId = authUser.id,
                    userId = authUser.id,
                    role = authUser.role,
                    isOnline = true
                )

                if (authUser.role == UserRole.CONTROLLER) {
                    loadCommandHistory(newSession)
                    loadVideos(newSession)
                } else if (authUser.role == UserRole.DOLIA) {
                    loadVideos(newSession)
                }
            }.onFailure { err ->
                _authLoading.value = false
                _authError.value = err.message ?: "Koneksi ke Supabase gagal"
            }
        }
    }

    private fun connectRealtime(sessionData: SessionData) {
        val config = _supabaseConfig.value
        realtimeClient.connect(
            config = config,
            token = sessionData.token,
            role = sessionData.user.role,
            userId = sessionData.user.id,
            roomId = if (sessionData.user.role == UserRole.DOLIA) sessionData.user.id else sessionData.user.studioId
        )
    }

    private fun loadCommandHistory(sessionData: SessionData) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = databaseClient.fetchCommandHistory(
                config = _supabaseConfig.value,
                token = sessionData.token
            )
            result.onSuccess { items ->
                if (items.isNotEmpty()) {
                    _commandHistory.value = items
                }
            }
        }
    }

    // =========================================================================
    // VIDEO MANAGER METHODS (Exclusive to Dolia Studio)
    // =========================================================================
    fun loadVideos(sessionData: SessionData? = _session.value) {
        val sess = sessionData ?: return
        if (sess.user.role != UserRole.DOLIA && sess.user.role != UserRole.CONTROLLER) return

        viewModelScope.launch(Dispatchers.IO) {
            _videoLoading.value = true

            // If in demo / offline mode, load from local storage
            if (sess.token == "demo-offline-token" || sess.serverUrl.contains("dummy.supabase.co") || sess.serverUrl.contains("your-project.supabase.co")) {
                val localList = if (sess.user.role == UserRole.DOLIA) localVideoManager.getVideos() else emptyList()
                _videos.value = localList
                _activeIdleVideo.value = localList.firstOrNull { it.isActiveIdle }
                    ?: localList.firstOrNull { it.category == VideoCategory.IDLE }
                _activeSpeakVideo.value = localList.firstOrNull { it.isActiveSpeak }
                    ?: localList.firstOrNull { it.category == VideoCategory.SPEAK }
                _videoLoading.value = false
                return@launch
            }

            val result = storageClient.fetchVideos(
                config = _supabaseConfig.value,
                token = sess.token
            )
            result.onSuccess { list ->
                // Also merge local videos if any
                val localList = if (sess.user.role == UserRole.DOLIA) localVideoManager.getVideos() else emptyList()
                val merged = (list + localList).distinctBy { it.id }
                _videos.value = merged
                _activeIdleVideo.value = merged.firstOrNull { it.isActiveIdle }
                    ?: merged.firstOrNull { it.category == VideoCategory.IDLE }
                _activeSpeakVideo.value = merged.firstOrNull { it.isActiveSpeak }
                    ?: merged.firstOrNull { it.category == VideoCategory.SPEAK }
                _videoLoading.value = false
            }.onFailure { err ->
                Log.w(TAG, "Load remote videos note: ${err.message}, loading local fallback")
                val localList = if (sess.user.role == UserRole.DOLIA) localVideoManager.getVideos() else emptyList()
                _videos.value = localList
                _activeIdleVideo.value = localList.firstOrNull { it.isActiveIdle }
                    ?: localList.firstOrNull { it.category == VideoCategory.IDLE }
                _activeSpeakVideo.value = localList.firstOrNull { it.isActiveSpeak }
                    ?: localList.firstOrNull { it.category == VideoCategory.SPEAK }
                _videoLoading.value = false
            }
        }
    }

    fun uploadVideo(
        context: Context,
        uri: Uri,
        category: VideoCategory,
        customName: String? = null,
        uploadToCloud: Boolean = true
    ) {
        val sess = _session.value ?: return

        viewModelScope.launch(Dispatchers.IO) {
            var tempFile: File? = null
            try {
                _videoLoading.value = true
                _videoErrorMessage.value = null
                _videoSuccessMessage.value = null
                _videoUploadProgress.value = "Menyiapkan berkas video..."

                // 1. Resolve actual display name and mime type
                val contentResolver = context.contentResolver
                var detectedName: String? = null
                var detectedSize: Long = 0L

                try {
                    contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (cursor.moveToFirst()) {
                            if (nameIndex != -1) detectedName = cursor.getString(nameIndex)
                            if (sizeIndex != -1) detectedSize = cursor.getLong(sizeIndex)
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Cannot query cursor: ${e.message}")
                }

                val mimeType = contentResolver.getType(uri) ?: "video/mp4"
                val extension = if (mimeType.contains("webm", ignoreCase = true)) "webm" else "mp4"

                val baseName = if (!customName.isNullOrBlank()) {
                    val clean = customName.trim()
                    if (clean.endsWith(".mp4", ignoreCase = true) || clean.endsWith(".webm", ignoreCase = true)) clean else "$clean.$extension"
                } else if (!detectedName.isNullOrBlank()) {
                    detectedName!!
                } else {
                    when (category) {
                        VideoCategory.IDLE -> "DOLIA_IDLE.mp4"
                        VideoCategory.SPEAK -> "DOLIA_SPEAK.mp4"
                        VideoCategory.REACTION -> "REACTION_${System.currentTimeMillis()}.$extension"
                    }
                }

                // 2. Stream into a temporary file in cache to prevent OutOfMemoryError
                _videoUploadProgress.value = "Menyalin stream video..."
                tempFile = File(context.cacheDir, "dolia_temp_${System.currentTimeMillis()}.$extension")
                val inputStream = contentResolver.openInputStream(uri)
                if (inputStream == null) {
                    _videoErrorMessage.value = "Tidak dapat membuka sumber video"
                    _videoLoading.value = false
                    _videoUploadProgress.value = null
                    return@launch
                }

                inputStream.use { input ->
                    tempFile.outputStream().use { output ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    }
                }

                if (!tempFile.exists() || tempFile.length() <= 0L) {
                    _videoErrorMessage.value = "File video kosong atau gagal disalin"
                    _videoLoading.value = false
                    _videoUploadProgress.value = null
                    return@launch
                }

                val fileSize = tempFile.length()
                Log.d(TAG, "Video temp file created: ${tempFile.absolutePath} ($fileSize bytes)")

                val isOfflineOrDemo = sess.token == "demo-offline-token" ||
                    sess.serverUrl.contains("dummy.supabase.co") ||
                    sess.serverUrl.contains("your-project.supabase.co") ||
                    !uploadToCloud

                if (isOfflineOrDemo) {
                    _videoUploadProgress.value = "Menyimpan video ke penyimpanan lokal..."
                    val saved = localVideoManager.saveVideoFromFile(
                        fileName = baseName,
                        category = category,
                        sourceFile = tempFile,
                        setAsIdle = category == VideoCategory.IDLE,
                        setAsSpeak = category == VideoCategory.SPEAK
                    )
                    _videoSuccessMessage.value = "Video '${saved.name}' berhasil disimpan ke penyimpanan lokal perangkat!"
                    _videoUploadProgress.value = null
                    _videoLoading.value = false
                    loadVideos(sess)
                    return@launch
                }

                // 3. Upload to Supabase Storage
                _videoUploadProgress.value = "Memverifikasi bucket Supabase Storage..."
                val bucketCheck = storageClient.ensureBucketExists(_supabaseConfig.value, sess.token)
                if (bucketCheck.isFailure) {
                    Log.w(TAG, "Bucket check warning: ${bucketCheck.exceptionOrNull()?.message}")
                }

                val storageFileName = "${category.value}_${System.currentTimeMillis()}_$baseName"
                _videoUploadProgress.value = "Mengunggah video (${fileSize / (1024 * 1024)} MB)..."

                val uploadResult = storageClient.uploadVideoFromFile(
                    config = _supabaseConfig.value,
                    token = sess.token,
                    fileName = storageFileName,
                    mimeType = mimeType,
                    file = tempFile
                )

                uploadResult.onSuccess { publicUrl ->
                    _videoUploadProgress.value = "Mendaftarkan metadata video..."
                    val videoId = "vid_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(4)}"
                    val isIdle = category == VideoCategory.IDLE && (_activeIdleVideo.value == null || baseName.contains("IDLE", ignoreCase = true))
                    val isSpeak = category == VideoCategory.SPEAK && (_activeSpeakVideo.value == null || baseName.contains("SPEAK", ignoreCase = true))

                    val videoItem = DoliaVideoItem(
                        id = videoId,
                        name = baseName,
                        category = category,
                        url = publicUrl,
                        storagePath = storageFileName,
                        sizeBytes = fileSize,
                        isActiveIdle = isIdle,
                        isActiveSpeak = isSpeak,
                        createdAt = System.currentTimeMillis()
                    )

                    val dbResult = storageClient.insertVideoMetadata(
                        config = _supabaseConfig.value,
                        token = sess.token,
                        video = videoItem,
                        userId = sess.user.id
                    )

                    dbResult.onSuccess {
                        _videoSuccessMessage.value = "Video '$baseName' berhasil diunggah ke Supabase Storage & Database!"
                        _videoUploadProgress.value = null
                        _videoLoading.value = false
                        loadVideos(sess)
                    }.onFailure { err ->
                        // Cloud storage succeeded, save local metadata backup
                        localVideoManager.saveVideoFromFile(
                            fileName = baseName,
                            category = category,
                            sourceFile = tempFile,
                            setAsIdle = isIdle,
                            setAsSpeak = isSpeak
                        )
                        _videoErrorMessage.value = "Video terunggah ke Cloud Storage, namun metadata database gagal (${err.message}). Disimpan juga secara lokal."
                        _videoLoading.value = false
                        _videoUploadProgress.value = null
                        loadVideos(sess)
                    }
                }.onFailure { err ->
                    // Fallback seamlessly to local storage
                    Log.w(TAG, "Storage upload failed: ${err.message}, saving to device storage")
                    val saved = localVideoManager.saveVideoFromFile(
                        fileName = baseName,
                        category = category,
                        sourceFile = tempFile,
                        setAsIdle = category == VideoCategory.IDLE,
                        setAsSpeak = category == VideoCategory.SPEAK
                    )
                    _videoErrorMessage.value = "Upload Cloud gagal (${err.message}). Video berhasil dialihkan & tersimpan aman di penyimpanan lokal perangkat!"
                    _videoUploadProgress.value = null
                    _videoLoading.value = false
                    loadVideos(sess)
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Upload fatal error: ${t.message}", t)
                _videoErrorMessage.value = "Kesalahan upload: ${t.message ?: "Memori atau I/O error"}"
                _videoLoading.value = false
                _videoUploadProgress.value = null
            } finally {
                try {
                    tempFile?.delete()
                } catch (e: Exception) {
                    // Ignore temp file cleanup
                }
            }
        }
    }

    fun refreshVideos() {
        val sess = _session.value ?: return
        loadVideos(sess)
    }

    /**
     * Controller chooses a video to immediately display in Dolia Studio
     */
    fun selectVideoForDolia(video: DoliaVideoItem, category: VideoCategory) {
        viewModelScope.launch {
            val sent = realtimeClient.sendSelectVideoCommand(
                videoId = video.id,
                videoUrl = video.url,
                videoName = video.name,
                category = category.value
            )

            // Update local state too, so the Studio reacts instantly when this
            // device is the Studio endpoint (demo/local mode).
            when (category) {
                VideoCategory.IDLE -> {
                    _studioVideoMode.value = VideoCategory.IDLE
                    _activeReactionVideo.value = null
                    _activeIdleVideo.value = video
                    _videos.value = _videos.value.map {
                        it.copy(isActiveIdle = it.id == video.id)
                    }
                    if (_session.value?.user?.role == UserRole.DOLIA) {
                        localVideoManager.setActive(video.id, setAsIdle = true, setAsSpeak = false)
                    }
                }
                VideoCategory.SPEAK -> {
                    _studioVideoMode.value = VideoCategory.SPEAK
                    _activeSpeakVideo.value = video
                    _videos.value = _videos.value.map {
                        it.copy(isActiveSpeak = it.id == video.id)
                    }
                    if (_session.value?.user?.role == UserRole.DOLIA) {
                        localVideoManager.setActive(video.id, setAsIdle = false, setAsSpeak = true)
                    }
                }
                VideoCategory.REACTION -> {
                    _studioVideoMode.value = VideoCategory.REACTION
                    _activeReactionVideo.value = video
                }
            }

            _lastSentFeedback.value = if (sent) {
                "✓ Video '${video.name}' (${category.label}) dikirim ke Dolia Studio."
            } else {
                "⚠ Video '${video.name}' dipilih, tetapi Dolia belum terhubung. Pastikan Studio online."
            }
        }
    }

    /**
     * Resets Dolia Studio back to the active IDLE video
     */
    fun clearReactionVideo() {
        _activeReactionVideo.value = null
        _studioVideoMode.value = VideoCategory.IDLE
        realtimeClient.sendSelectVideoCommand(
            videoId = "",
            videoUrl = "",
            videoName = "",
            category = "clear_reaction"
        )
        _lastSentFeedback.value = "Dolia Studio kembali ke mode IDLE"
    }

    fun setActiveVideo(videoId: String, setAsIdle: Boolean, setAsSpeak: Boolean) {
        val sess = _session.value ?: return

        viewModelScope.launch(Dispatchers.IO) {
            _videoLoading.value = true

            // Update local manager first if present
            localVideoManager.setActive(videoId, setAsIdle, setAsSpeak)

            if (sess.token != "demo-offline-token") {
                val result = storageClient.setActiveVideo(
                    config = _supabaseConfig.value,
                    token = sess.token,
                    videoId = videoId,
                    setAsIdle = setAsIdle,
                    setAsSpeak = setAsSpeak
                )
                result.onFailure { err ->
                    Log.w(TAG, "Remote setActiveVideo note: ${err.message}")
                }
            }
            loadVideos(sess)
        }
    }

    fun deleteVideo(videoId: String, storagePath: String) {
        val sess = _session.value ?: return

        viewModelScope.launch(Dispatchers.IO) {
            _videoLoading.value = true

            localVideoManager.deleteVideo(videoId)

            if (sess.token != "demo-offline-token") {
                val result = storageClient.deleteVideo(
                    config = _supabaseConfig.value,
                    token = sess.token,
                    videoId = videoId,
                    storagePath = storagePath
                )
                result.onFailure { err ->
                    Log.w(TAG, "Remote deleteVideo note: ${err.message}")
                }
            }
            loadVideos(sess)
        }
    }

    fun clearVideoError() {
        _videoErrorMessage.value = null
    }

    fun clearVideoSuccess() {
        _videoSuccessMessage.value = null
    }

    fun reconnect() {
        _session.value?.let { sess ->
            connectRealtime(sess)
        }
    }

    fun sendSpeak() {
        val text = _inputText.value.trim()
        if (text.isEmpty()) return

        val cmdId = "cmd_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(5)}"
        val newItem = CommandHistoryItem(
            id = cmdId,
            text = text,
            timestamp = System.currentTimeMillis(),
            status = if (realtimeClient.connectionStatus.value == ConnectionStatus.CONNECTED) "Sending..." else "Waiting Supabase..."
        )
        _commandHistory.value = listOf(newItem) + _commandHistory.value
        _inputText.value = ""

        // 1. Send via Supabase Realtime Broadcast
        val sent = realtimeClient.sendSpeakCommand(text, cmdId)
        if (sent) {
            _lastSentFeedback.value = "Teks terkirim ke Supabase Realtime"
        } else {
            _lastSentFeedback.value = "Supabase Realtime menghubungkan ulang..."
            reconnect()
        }

        // 2. Persist to PostgreSQL commands table via PostgREST (governed by RLS)
        _session.value?.let { sess ->
            if (sess.token != "demo-offline-token") {
                viewModelScope.launch(Dispatchers.IO) {
                    val dbResult = databaseClient.insertCommand(
                        config = _supabaseConfig.value,
                        token = sess.token,
                        commandId = cmdId,
                        senderId = sess.user.id,
                        text = text,
                        recipientRole = "dolia"
                    )
                    dbResult.onSuccess { savedItem ->
                        _commandHistory.value = _commandHistory.value.map { item ->
                            if (item.id == cmdId) savedItem else item
                        }
                    }.onFailure { err ->
                        Log.w(TAG, "PostgreSQL insert note: ${err.message}")
                    }
                }
            }
        }
    }

    fun clearFeedback() {
        _lastSentFeedback.value = null
    }

    fun clearHistory() {
        _commandHistory.value = emptyList()
    }

    fun returnToIdleVideo() {
        if (_activeIdleVideo.value != null) {
            _activeReactionVideo.value = null
            _studioVideoMode.value = VideoCategory.IDLE
        }
    }

    fun testLocalTts(sampleText: String = "Halo! Ini adalah suara Dolia AI melalui Supabase Realtime.") {
        ttsEngine.speak(sampleText)
    }

    fun logout() {
        _session.value?.let { sess ->
            if (sess.token != "demo-offline-token") {
                viewModelScope.launch(Dispatchers.IO) {
                    databaseClient.upsertDeviceStatus(
                        config = _supabaseConfig.value,
                        token = sess.token,
                        deviceId = sess.user.id,
                        userId = sess.user.id,
                        role = sess.user.role,
                        isOnline = false
                    )
                }
            }
        }
        realtimeClient.disconnect()
        ttsEngine.stop()
        sessionManager.clearSession()
        _session.value = null
        _commandHistory.value = emptyList()
        _inputText.value = ""
        _authError.value = null
        _videos.value = emptyList()
        _activeIdleVideo.value = null
        _activeSpeakVideo.value = null
    }

    override fun onCleared() {
        super.onCleared()
        realtimeClient.disconnect()
        ttsEngine.shutdown()
    }
}
