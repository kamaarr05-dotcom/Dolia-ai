package com.example.ui.dolia

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionStatus
import com.example.data.model.DoliaSpeechStatus
import com.example.ui.MainViewModel
import com.example.ui.components.ConnectionPill
import com.example.ui.components.ServerConfigDialog
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonRed
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DoliaStudioScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val session by viewModel.session.collectAsState()
    val serverUrl by viewModel.serverUrl.collectAsState()
    val supabaseConfig by viewModel.supabaseConfig.collectAsState()
    val connectionStatus by viewModel.connectionStatus.collectAsState()
    val speechStatus by viewModel.speechStatus.collectAsState()
    val currentSpokenText by viewModel.currentSpokenText.collectAsState()
    val activeIdleVideo by viewModel.activeIdleVideo.collectAsState()
    val activeSpeakVideo by viewModel.activeSpeakVideo.collectAsState()
    val activeReactionVideo by viewModel.activeReactionVideo.collectAsState()
    val studioVideoMode by viewModel.studioVideoMode.collectAsState()

    var showServerDialog by remember { mutableStateOf(false) }
    var showVideoManager by remember { mutableStateOf(false) }
    var showControllerRegister by remember { mutableStateOf(false) }
    var controllerEmail by remember { mutableStateOf("") }
    var controllerPassword by remember { mutableStateOf("") }
    var isCleanScreenMode by remember { mutableStateOf(false) }
    val controllerRegistrationLoading by viewModel.controllerRegistrationLoading.collectAsState()
    val controllerRegistrationMessage by viewModel.controllerRegistrationMessage.collectAsState()

    if (showServerDialog) {
        ServerConfigDialog(
            currentUrl = serverUrl,
            currentAnonKey = supabaseConfig.anonKey,
            onDismiss = { showServerDialog = false },
            onSave = { url, key -> viewModel.updateServerUrl(url, key) }
        )
    }

    if (showVideoManager) {
        VideoManagerDialog(
            viewModel = viewModel,
            onDismiss = { showVideoManager = false }
        )
    }

    if (showControllerRegister) {
        AlertDialog(
            onDismissRequest = {
                if (!controllerRegistrationLoading) showControllerRegister = false
            },
            title = { Text("Daftar Akun Controller", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Akun ini akan otomatis diberi role Controller dan dipasangkan ke DOLIA Studio yang sedang login.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = controllerEmail,
                        onValueChange = { controllerEmail = it },
                        label = { Text("Email Controller") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = controllerPassword,
                        onValueChange = { controllerPassword = it },
                        label = { Text("Password Controller") },
                        singleLine = true
                    )
                    controllerRegistrationMessage?.let {
                        Text(it, color = if (it.startsWith("Akun Controller")) NeonGreen else NeonRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = !controllerRegistrationLoading,
                    onClick = { viewModel.registerControllerAccount(controllerEmail, controllerPassword) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                ) {
                    Text(if (controllerRegistrationLoading) "Mendaftarkan..." else "DAFTARKAN", color = Color.Black)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = {
                        if (!controllerRegistrationLoading) {
                            viewModel.clearControllerRegistrationMessage()
                            showControllerRegister = false
                        }
                    }
                ) { Text("Tutup", color = TextSecondary) }
            }
        )
    }

    val isSpeaking = speechStatus == DoliaSpeechStatus.SPEAKING

    // The Controller explicitly selects which video the Studio should display.
    // SPEAK also becomes active while TTS is speaking; REACTION has priority.
    val currentVideoUrl = when (studioVideoMode) {
        com.example.data.model.VideoCategory.REACTION -> activeReactionVideo?.url ?: activeIdleVideo?.url
        com.example.data.model.VideoCategory.SPEAK -> activeSpeakVideo?.url ?: activeIdleVideo?.url
        com.example.data.model.VideoCategory.IDLE -> activeIdleVideo?.url
    }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("dolia_studio_screen"),
        color = ObsidianBg
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // 1. Video Player Layer (Fullscreen Hardware Accelerated)
            if (!currentVideoUrl.isNullOrBlank()) {
                val shouldLoop = studioVideoMode == com.example.data.model.VideoCategory.IDLE
                DoliaVideoPlayer(
                    videoUrl = currentVideoUrl,
                    isLooping = shouldLoop,
                    modifier = Modifier.fillMaxSize(),
                    onVideoEnded = {
                        // SPEAK/REACTION are one-shot clips. Always return to the
                        // last active IDLE clip when the selected clip finishes.
                        if (studioVideoMode != com.example.data.model.VideoCategory.IDLE) {
                            viewModel.returnToIdleVideo()
                        }
                    }
                )
                // High-clarity subtle gradient scrim to keep overlays legible (hidden in clean screen mode)
                if (!isCleanScreenMode) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        ObsidianBg.copy(alpha = 0.65f),
                                        Color.Transparent,
                                        ObsidianBg.copy(alpha = 0.75f)
                                    )
                                )
                            )
                    )
                }
            } else {
                // Futuristic Holographic Avatar Fallback when no video is loaded
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val centerOffset = Offset(size.width / 2, size.height / 2)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                if (isSpeaking) CyberCyan.copy(alpha = 0.15f) else ElectricViolet.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = centerOffset,
                            radius = size.width * 0.7f
                        ),
                        center = centerOffset,
                        radius = size.width * 0.7f
                    )
                }
            }

            // 2. UI Overlay Controls (Hidden in Clean Screen Mode)
            AnimatedVisibility(
                visible = !isCleanScreenMode,
                enter = fadeIn(animationSpec = tween(300)),
                exit = fadeOut(animationSpec = tween(300))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                // Top Clean Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "DOLIA",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                letterSpacing = 3.sp,
                                color = CyberCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "STUDIO",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                letterSpacing = 2.sp,
                                color = TextPrimary
                            )
                            if (currentVideoUrl != null) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(ObsidianCard.copy(alpha = 0.8f))
                                        .border(1.dp, if (isSpeaking) NeonMagenta else CyberCyan, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Movie,
                                        contentDescription = null,
                                        tint = if (isSpeaking) NeonMagenta else CyberCyan,
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isSpeaking) "SPEAK.mp4" else "IDLE.mp4",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSpeaking) NeonMagenta else CyberCyan,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                        Text(
                            text = "Device: Android TTS / Supabase",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ConnectionPill(status = connectionStatus)
                        Spacer(modifier = Modifier.width(4.dp))
                        // Tombol Layar Bersih / Layar Penuh (Menyembunyikan teks & antarmuka)
                        IconButton(
                            onClick = { isCleanScreenMode = true },
                            modifier = Modifier.testTag("dolia_clean_screen_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fullscreen,
                                contentDescription = "Layar Bersih",
                                tint = CyberCyan
                            )
                        }
                        // Video Manager Action Button (Exclusive to Dolia Studio)
                        IconButton(
                            onClick = { showVideoManager = true },
                            modifier = Modifier.testTag("dolia_video_manager_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Video Manager",
                                tint = CyberCyan
                            )
                        }
                        Button(
                            onClick = {
                                viewModel.clearControllerRegistrationMessage()
                                showControllerRegister = true
                            },
                            modifier = Modifier.height(36.dp).testTag("dolia_register_controller_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Daftar Controller", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        IconButton(
                            onClick = { viewModel.reconnect() },
                            modifier = Modifier.testTag("dolia_reconnect_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reconnect",
                                tint = TextSecondary
                            )
                        }
                        IconButton(
                            onClick = { showServerDialog = true },
                            modifier = Modifier.testTag("dolia_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = TextSecondary
                            )
                        }
                        IconButton(
                            onClick = { viewModel.logout() },
                            modifier = Modifier.testTag("dolia_logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Logout",
                                tint = NeonRed
                            )
                        }
                    }
                }

                // Center AI Entertainer Orb & Waveform Display (shown when no video is active)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (currentVideoUrl.isNullOrBlank()) {
                        DoliaCoreVisualizer(isSpeaking = isSpeaking)
                        Spacer(modifier = Modifier.height(28.dp))
                    }

                    // Realtime Status Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                if (isSpeaking) CyberCyan.copy(alpha = 0.25f)
                                else ObsidianCard.copy(alpha = 0.85f)
                            )
                            .border(
                                1.dp,
                                if (isSpeaking) CyberCyan else ObsidianBorder,
                                RoundedCornerShape(20.dp)
                            )
                            .padding(horizontal = 20.dp, vertical = 8.dp)
                            .testTag("dolia_status_indicator")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(
                                        if (isSpeaking) CyberCyan else NeonGreen,
                                        CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isSpeaking) "BERBICARA (SPEAKING)..." else "STATUS: IDLE • STANDBY",
                                color = if (isSpeaking) CyberCyan else TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Spoken Text Subtitle Container
                    AnimatedVisibility(
                        visible = isSpeaking && currentSpokenText.isNotEmpty(),
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .testTag("spoken_text_card"),
                            colors = CardDefaults.cardColors(containerColor = ObsidianCard.copy(alpha = 0.92f)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "MENYUARAKAN TEKS DARI CONTROLLER:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = TextSecondary
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "\"$currentSpokenText\"",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 26.sp
                                )
                            }
                        }
                    }

                    if (!isSpeaking && currentVideoUrl.isNullOrBlank()) {
                        Text(
                            text = "Menunggu perintah dari Controller realtime...",
                            fontSize = 13.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Bottom Minimal Controls & Test Speech
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Realtime Engine: Supabase Realtime (ws)",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace
                    )

                    // Quick test TTS button on device
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(ObsidianCard.copy(alpha = 0.85f))
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(8.dp))
                            .clickable {
                                viewModel.testLocalTts("Halo, sistem suara Dolia berfungsi dengan baik.")
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("test_tts_button"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Test TTS",
                            tint = CyberCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Test Suara",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

            // 3. Clean Screen Mode Touch Layer (Ketuk 2x / double tap di mana saja untuk mengembalikan menu)
            if (isCleanScreenMode) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onDoubleTap = {
                                    isCleanScreenMode = false
                                }
                            )
                        }
                        .testTag("dolia_clean_screen_touch_layer")
                )
            }
        }
    }
}

@Composable
private fun DoliaCoreVisualizer(
    isSpeaking: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "core_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeaking) 400 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val coreColor = if (isSpeaking) CyberCyan else ElectricViolet

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier.size(200.dp)
    ) {
        // Outer concentric animated waves
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val baseRadius = (size.width / 2) * 0.75f * pulseScale

            // Outer glow ring
            drawCircle(
                color = coreColor.copy(alpha = if (isSpeaking) 0.35f else 0.15f),
                radius = baseRadius * 1.25f,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Middle ring
            drawCircle(
                color = coreColor.copy(alpha = if (isSpeaking) 0.6f else 0.25f),
                radius = baseRadius,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )

            // Inner filled glowing core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = if (isSpeaking) 0.9f else 0.5f),
                        coreColor.copy(alpha = 0.1f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 0.7f
                ),
                radius = baseRadius * 0.7f,
                center = center
            )
        }

        // Inner glowing core emblem
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(ObsidianCard)
                .border(2.dp, coreColor, CircleShape)
        ) {
            Text(
                text = "D",
                color = coreColor,
                fontSize = 32.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}
