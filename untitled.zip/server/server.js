/**
 * DOLIA V1 - Supabase Migration Info & Documentation Server
 * Backend has been fully migrated to Supabase (Auth, PostgreSQL with RLS, Supabase Realtime).
 * This lightweight server provides the schema overview and status endpoint on port 3000.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const schemaSqlPath = path.join(__dirname, '..', 'supabase', 'schema.sql');

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, apikey');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.url === '/api/status' || req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'migrated_to_supabase',
      backend: 'Supabase Cloud (PostgreSQL + Auth + Realtime)',
      roles: ['controller', 'dolia'],
      rls_enabled: true,
      timestamp: new Date().toISOString()
    }));
    return;
  }

  if (req.url === '/schema.sql') {
    if (fs.existsSync(schemaSqlPath)) {
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end(fs.readFileSync(schemaSqlPath, 'utf8'));
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Schema file not found');
    }
    return;
  }

  // Dashboard page
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>DOLIA V1 - Supabase Cloud Backend</title>
  <style>
    body {
      background: #0B0E14;
      color: #F0F6FC;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 30px;
    }
    .container { max-width: 900px; margin: 0 auto; }
    h1 { color: #00F0FF; font-size: 28px; letter-spacing: 2px; margin-bottom: 5px; }
    .badge {
      display: inline-block;
      background: rgba(0, 255, 102, 0.15);
      border: 1px solid #00FF66;
      color: #00FF66;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .card {
      background: #111827;
      border: 1px solid #1F2937;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 20px;
    }
    h2 { color: #8A2BE2; font-size: 18px; margin-top: 0; }
    pre {
      background: #06090E;
      border: 1px solid #1F2937;
      border-radius: 8px;
      padding: 14px;
      overflow-x: auto;
      font-size: 13px;
      color: #00F0FF;
    }
    ul { padding-left: 20px; color: #8B949E; line-height: 1.6; }
    li strong { color: #F0F6FC; }
    a { color: #00F0FF; text-decoration: none; font-weight: bold; }
  </style>
</head>
<body>
  <div class="container">
    <h1>DOLIA V1 &mdash; BACKEND MIGRATED TO SUPABASE</h1>
    <div class="badge">MIGRATION COMPLETED &bull; SUPABASE AUTH &bull; POSTGRESQL RLS &bull; SUPABASE REALTIME</div>

    <div class="card">
      <h2>Ringkasan Arsitektur Supabase DOLIA</h2>
      <ul>
        <li><strong>Satu Aplikasi & Dua Role:</strong> <code>controller</code> (Controller Panel) & <code>dolia</code> (Dolia Studio).</li>
        <li><strong>Autentikasi & Sesi:</strong> Dikelola langsung melalui Supabase Auth (JWT).</li>
        <li><strong>Database PostgreSQL:</strong> Tabel <code>profiles</code>, <code>commands</code> (history), dan <code>device_status</code>.</li>
        <li><strong>Row Level Security (RLS):</strong> Controller hanya dapat INSERT command, Dolia hanya membaca command yang ditujukan kepadanya.</li>
        <li><strong>Supabase Realtime:</strong> Realtime WebSocket Broadcast channel <code>realtime:dolia_channel</code> untuk pengiriman perintah SPEAK instan Controller &rarr; Dolia &rarr; Android TTS lokal.</li>
      </ul>
      <p><a href="/schema.sql" target="_blank">&rarr; Unduh / Lihat SQL Schema Supabase Lengkap (schema.sql)</a></p>
    </div>

    <div class="card">
      <h2>Environment Variables Android</h2>
      <pre>SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.your-anon-key-placeholder</pre>
      <p style="color:#8B949E;font-size:13px;"><em>Catatan Keamanan: Hanya anon public key yang digunakan pada aplikasi Android. Service role key tidak pernah disimpan di klien.</em></p>
    </div>
  </div>
</body>
</html>`);
});

server.listen(PORT, () => {
  console.log(`DOLIA Supabase Hub listening on http://localhost:${PORT}`);
});
