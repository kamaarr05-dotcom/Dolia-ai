package com.example.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.DoliaSpeechStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

class DoliaTtsEngine(
    context: Context,
    private val scope: CoroutineScope
) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "DoliaTTS"
    }

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false
    private val pendingQueue = mutableListOf<String>()

    private val _speechStatus = MutableStateFlow(DoliaSpeechStatus.IDLE)
    val speechStatus: StateFlow<DoliaSpeechStatus> = _speechStatus.asStateFlow()

    private val _currentSpokenText = MutableStateFlow("")
    val currentSpokenText: StateFlow<String> = _currentSpokenText.asStateFlow()

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    var onSpeechStatusChanged: ((isSpeaking: Boolean, text: String) -> Unit)? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val ttsEngine = tts ?: return
            
            // Prefer Indonesian for Indonesian audience / DOLIA prompt
            val indoLocale = Locale("id", "ID")
            val result = ttsEngine.setLanguage(indoLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Indonesian language not supported, falling back to default locale")
                ttsEngine.language = Locale.getDefault()
            }

            ttsEngine.setPitch(1.05f) // Slightly bright futuristic AI voice pitch
            ttsEngine.setSpeechRate(1.0f)

            ttsEngine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    scope.launch(Dispatchers.Main) {
                        _speechStatus.value = DoliaSpeechStatus.SPEAKING
                        onSpeechStatusChanged?.invoke(true, _currentSpokenText.value)
                    }
                }

                override fun onDone(utteranceId: String?) {
                    scope.launch(Dispatchers.Main) {
                        _speechStatus.value = DoliaSpeechStatus.IDLE
                        _currentSpokenText.value = ""
                        onSpeechStatusChanged?.invoke(false, "")
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    scope.launch(Dispatchers.Main) {
                        _speechStatus.value = DoliaSpeechStatus.IDLE
                        _currentSpokenText.value = ""
                        onSpeechStatusChanged?.invoke(false, "")
                    }
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    Log.e(TAG, "TTS Utterance error code: $errorCode")
                    scope.launch(Dispatchers.Main) {
                        _speechStatus.value = DoliaSpeechStatus.IDLE
                        _currentSpokenText.value = ""
                        onSpeechStatusChanged?.invoke(false, "")
                    }
                }
            })

            isInitialized = true
            _isReady.value = true
            Log.d(TAG, "TTS Engine successfully initialized")

            // Drain queued speech commands that arrived during init
            val queued = ArrayList(pendingQueue)
            pendingQueue.clear()
            queued.forEach { speak(it) }
        } else {
            Log.e(TAG, "TTS Initialization failed with code: $status")
            _isReady.value = false
        }
    }

    fun speak(text: String) {
        val cleanText = text.trim()
        if (cleanText.isEmpty()) return

        if (!isInitialized || tts == null) {
            Log.w(TAG, "TTS not ready yet. Queuing text: $cleanText")
            pendingQueue.add(cleanText)
            return
        }

        _currentSpokenText.value = cleanText
        _speechStatus.value = DoliaSpeechStatus.SPEAKING

        val utteranceId = UUID.randomUUID().toString()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        val result = tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        if (result != TextToSpeech.SUCCESS) {
            Log.e(TAG, "tts.speak returned error code: $result")
            _speechStatus.value = DoliaSpeechStatus.IDLE
            _currentSpokenText.value = ""
            onSpeechStatusChanged?.invoke(false, "")
        }
    }

    fun stop() {
        pendingQueue.clear()
        tts?.stop()
        _speechStatus.value = DoliaSpeechStatus.IDLE
        _currentSpokenText.value = ""
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            Log.e(TAG, "Error shutting down TTS", e)
        }
    }
}
