package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UserRole
import com.example.ui.MainViewModel
import com.example.ui.auth.LoginScreen
import com.example.ui.controller.ControllerPanelScreen
import com.example.ui.dolia.DoliaStudioScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBg

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: MainViewModel = viewModel()
                DoliaApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun DoliaApp(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val session by viewModel.session.collectAsState()

    Surface(
        modifier = modifier.fillMaxSize(),
        color = ObsidianBg
    ) {
        when {
            session == null -> {
                LoginScreen(viewModel = viewModel)
            }
            session?.user?.role == UserRole.CONTROLLER -> {
                ControllerPanelScreen(viewModel = viewModel)
            }
            session?.user?.role == UserRole.DOLIA -> {
                DoliaStudioScreen(viewModel = viewModel)
            }
            else -> {
                LoginScreen(viewModel = viewModel)
            }
        }
    }
}
