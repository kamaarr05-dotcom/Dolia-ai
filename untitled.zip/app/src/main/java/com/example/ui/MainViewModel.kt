package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SessionManager
import com.example.data.model.AuthUser
import com.example.data.model.CommandHistoryItem
import com.example.data.model.ConnectionStatus
import com.example.data.model.DoliaSpeechStatus
import com.example.data.model.DoliaVideoItem
import com.example.data.model.SessionData
import com.example.data.model.UserRole
import com.example.data.model.VideoCategory
import com.example.data.supabase.SupabaseAuthClient
import com.example.data.supabase.SupabaseConfig
import com.example.data.supabase.SupabaseDatabaseClient
import com.example.data.supabase.SupabaseRealtimeClient
import com.example.data.supabase.SupabaseStorageClient
import com.example.tts.DoliaTtsEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "MainViewModel"
    }

    private val sessionManager = SessionManager(application)
    private val authClient = SupabaseAuthClient()
    private val databaseClient = SupabaseDatabaseClient()
    private val storageClient = SupabaseStorageClient()
    private val realtimeClient = SupabaseRealtimeClient(viewModelScope)
    val ttsEngine = DoliaTtsEngine(application, viewModelScope)

    // Current Session
    private val _session = MutableStateFlow<SessionData?>(null)
    val session: StateFlow<SessionData?> = _session.asStateFlow()

    // Supabase Config State
    private val _supabaseConfig = MutableStateFlow(sessionManager.getSupabaseConfig())
    val supabaseConfig: StateFlow<SupabaseConfig> = _supabaseConfig.asStateFlow()
    private val _serverUrl = MutableStateFlow(_supabaseConfig.value.cleanUrl)
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    // Auth Form State
    private val _username = MutableStateFlow("controller")
    val username: StateFlow<String> = _username.asStateFlow()

    private val _password = MutableStateFlow("controller123")
    val password: StateFlow<String> = _password.asStateFlow()

    private val _selectedRole = MutableStateFlow(UserRole.CONTROLLER)
    val selectedRole: StateFlow<UserRole> = _selectedRole.asStateFlow()

    private val _isRegisterMode = MutableStateFlow(false)
    val isRegisterMode: StateFlow<Boolean> = _isRegisterMode.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    // Realtime States
    val connectionStatus: StateFlow<ConnectionStatus> = realtimeClient.connectionStatus
    val isDoliaOnline: StateFlow<Boolean> = realtimeClient.isDoliaOnline
    val doliaCount: StateFlow<Int> = realtimeClient.doliaCount

    // Controller Panel State
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _commandHistory = MutableStateFlow<List<CommandHistoryItem>>(emptyList())
    val commandHistory: StateFlow<List<CommandHistoryItem>> = _commandHistory.asStateFlow()

    private val _lastSentFeedback = MutableStateFlow<String?>(null)
    val lastSentFeedback: StateFlow<String?> = _lastSentFeedback.asStateFlow()

    // Dolia Studio State
    val speechStatus: StateFlow<DoliaSpeechStatus> = ttsEngine.speechStatus
    val currentSpokenText: StateFlow<String> = ttsEngine.currentSpokenText

    // Video Manager State (Dolia Studio only)
    private val _videos = MutableStateFlow<List<DoliaVideoItem>>(emptyList())
    val videos: StateFlow<List<DoliaVideoItem>> = _videos.asStateFlow()

    private val _activeIdleVideo = MutableStateFlow<DoliaVideoItem?>(null)
    val activeIdleVideo: StateFlow<DoliaVideoItem?> = _activeIdleVideo.asStateFlow()

    private val _activeSpeakVideo = MutableStateFlow<DoliaVideoItem?>(null)
    val activeSpeakVideo: StateFlow<DoliaVideoItem?> = _activeSpeakVideo.asStateFlow()

    private val _videoLoading = MutableStateFlow(false)
    val videoLoading: StateFlow<Boolean> = _videoLoading.asStateFlow()

    private val _videoUploadProgress = MutableStateFlow<String?>(null)
    val videoUploadProgress: StateFlow<String?> = _videoUploadProgress.asStateFlow()

    private val _videoErrorMessage = MutableStateFlow<String?>(null)
    val videoErrorMessage: StateFlow<String?> = _videoErrorMessage.asStateFlow()

    init {
        // Wire Realtime callbacks
        realtimeClient.onSpeakCommandReceived = { text, id ->
            if (_session.value?.user?.role == UserRole.DOLIA) {
                Log.d(TAG, "Dolia triggering local Android TTS for command: $id")
                ttsEngine.speak(text)
            }
        }

        realtimeClient.onCommandAckReceived = { id, status, count ->
            _commandHistory.value = _commandHistory.value.map { item ->
                if (item.id == id) {
                    item.copy(
                        status = if (status == "delivered") "Delivered to Dolia" else "Queued (Dolia Offline)",
                        doliaCount = count
                    )
                } else item
            }
        }

        ttsEngine.onSpeechStatusChanged = { isSpeaking, text ->
            if (_session.value?.user?.role == UserRole.DOLIA) {
                realtimeClient.notifySpeechStatus(isSpeaking, text)
            }
        }

        realtimeClient.onAuthFailed = {
            viewModelScope.launch(Dispatchers.Main) {
                _authError.value = "Sesi Supabase telah kedaluwarsa. Silakan login kembali."
                logout()
            }
        }

        // Restore saved session if present
        val savedSession = sessionManager.getSession()
        if (savedSession != null) {
            _session.value = savedSession
            _serverUrl.value = savedSession.serverUrl
            connectRealtime(savedSession)
            if (savedSession.user.role == UserRole.CONTROLLER) {
                loadCommandHistory(savedSession)
            } else if (savedSession.user.role == UserRole.DOLIA) {
                loadVideos(savedSession)
            }
        }
    }

    fun updateUsername(v: String) { _username.value = v }
    fun updatePassword(v: String) { _password.value = v }
    fun updateRole(r: UserRole) { _selectedRole.value = r }
    fun toggleRegisterMode() {
        _isRegisterMode.value = !_isRegisterMode.value
        _authError.value = null
    }

    fun updateServerUrl(url: String, anonKey: String? = null) {
        val clean = url.trimEnd('/')
        sessionManager.saveSupabaseConfig(clean, anonKey)
        val updatedConfig = sessionManager.getSupabaseConfig()
        _supabaseConfig.value = updatedConfig
        _serverUrl.value = updatedConfig.cleanUrl

        _session.value?.let { current ->
            val updatedSession = current.copy(serverUrl = updatedConfig.cleanUrl)
            _session.value = updatedSession
            sessionManager.saveSession(
                token = updatedSession.token,
                refreshToken = updatedSession.refreshToken,
                user = updatedSession.user,
                serverUrl = updatedConfig.cleanUrl
            )
            connectRealtime(updatedSession)
            if (updatedSession.user.role == UserRole.DOLIA) {
                loadVideos(updatedSession)
            }
        }
    }

    fun updateInputText(t: String) { _inputText.value = t }

    fun quickFill(role: UserRole) {
        when (role) {
            UserRole.CONTROLLER -> {
                _username.value = "controller"
                _password.value = "controller123"
                _selectedRole.value = UserRole.CONTROLLER
            }
            UserRole.DOLIA -> {
                _username.value = "dolia"
                _password.value = "dolia123"
                _selectedRole.value = UserRole.DOLIA
            }
        }
        _authError.value = null
    }

    fun login() {
        val user = _username.value.trim()
        val pass = _password.value
        val config = _supabaseConfig.value

        if (user.isEmpty() || pass.isEmpty()) {
            _authError.value = "Username dan password tidak boleh kosong"
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _authLoading.value = true
            _authError.value = null

            val result = if (_isRegisterMode.value) {
                authClient.register(
                    config = config,
                    usernameOrEmail = user,
                    password = pass,
                    role = _selectedRole.value
                )
            } else {
                authClient.login(
                    config = config,
                    usernameOrEmail = user,
                    password = pass
                )
            }

            result.onSuccess { authResult ->
                val authUser = authResult.user
                sessionManager.saveSession(
                    token = authResult.accessToken,
                    refreshToken = authResult.refreshToken,
                    user = authUser,
                    serverUrl = config.cleanUrl
                )
                val newSession = SessionData(
                    token = authResult.accessToken,
                    refreshToken = authResult.refreshToken,
                    user = authUser,
                    serverUrl = config.cleanUrl
                )
                _session.value = newSession
                _authLoading.value = false

                connectRealtime(newSession)

                // Update PostgreSQL device_status for Dolia or Controller
                databaseClient.upsertDeviceStatus(
                    config = config,
                    token = authResult.accessToken,
                    deviceId = authUser.id,
                    userId = authUser.id,
                    role = authUser.role,
                    isOnline = true
                )

                if (authUser.role == UserRole.CONTROLLER) {
                    loadCommandHistory(newSession)
                } else if (authUser.role == UserRole.DOLIA) {
                    loadVideos(newSession)
                }
            }.onFailure { err ->
                _authLoading.value = false
                _authError.value = err.message ?: "Koneksi ke Supabase gagal"
            }
        }
    }

    private fun connectRealtime(sessionData: SessionData) {
        val config = _supabaseConfig.value
        realtimeClient.connect(
            config = config,
            token = sessionData.token,
            role = sessionData.user.role,
            userId = sessionData.user.id
        )
    }

    private fun loadCommandHistory(sessionData: SessionData) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = databaseClient.fetchCommandHistory(
                config = _supabaseConfig.value,
                token = sessionData.token
            )
            result.onSuccess { items ->
                if (items.isNotEmpty()) {
                    _commandHistory.value = items
                }
            }
        }
    }

    // =========================================================================
    // VIDEO MANAGER METHODS (Exclusive to Dolia Studio)
    // =========================================================================

    fun loadVideos(sessionData: SessionData? = _session.value) {
        val sess = sessionData ?: return
        if (sess.user.role != UserRole.DOLIA) return

        viewModelScope.launch(Dispatchers.IO) {
            _videoLoading.value = true
            val result = storageClient.fetchVideos(
                config = _supabaseConfig.value,
                token = sess.token
            )
            result.onSuccess { list ->
                _videos.value = list
                _activeIdleVideo.value = list.firstOrNull { it.isActiveIdle }
                    ?: list.firstOrNull { it.category == VideoCategory.IDLE }
                _activeSpeakVideo.value = list.firstOrNull { it.isActiveSpeak }
                    ?: list.firstOrNull { it.category == VideoCategory.SPEAK }
                _videoLoading.value = false
            }.onFailure { err ->
                Log.w(TAG, "Load videos note: ${err.message}")
                _videoLoading.value = false
            }
        }
    }

    fun uploadVideo(
        context: Context,
        uri: Uri,
        category: VideoCategory,
        customName: String? = null
    ) {
        val sess = _session.value ?: return
        if (sess.user.role != UserRole.DOLIA) return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                _videoLoading.value = true
                _videoUploadProgress.value = "Membaca data video..."
                val contentResolver = context.contentResolver
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null || bytes.isEmpty()) {
                    _videoErrorMessage.value = "File video tidak dapat dibaca"
                    _videoLoading.value = false
                    _videoUploadProgress.value = null
                    return@launch
                }

                val mimeType = contentResolver.getType(uri) ?: "video/mp4"
                val extension = if (mimeType.contains("webm")) "webm" else "mp4"

                val baseName = if (!customName.isNullOrBlank()) {
                    val clean = customName.trim()
                    if (clean.endsWith(".mp4", ignoreCase = true) || clean.endsWith(".webm", ignoreCase = true)) clean else "$clean.$extension"
                } else {
                    when (category) {
                        VideoCategory.IDLE -> "DOLIA_IDLE.mp4"
                        VideoCategory.SPEAK -> "DOLIA_SPEAK.mp4"
                        VideoCategory.REACTION -> "REACTION_${System.currentTimeMillis()}.$extension"
                    }
                }

                val storageFileName = "${category.value}_${System.currentTimeMillis()}_$baseName"
                _videoUploadProgress.value = "Mengunggah video ke Supabase Storage..."

                val uploadResult = storageClient.uploadVideo(
                    config = _supabaseConfig.value,
                    token = sess.token,
                    fileName = storageFileName,
                    mimeType = mimeType,
                    bytes = bytes
                )

                uploadResult.onSuccess { publicUrl ->
                    _videoUploadProgress.value = "Menyimpan informasi ke database..."
                    val videoId = "vid_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(4)}"

                    val isIdle = category == VideoCategory.IDLE && (_activeIdleVideo.value == null || baseName.contains("IDLE", ignoreCase = true))
                    val isSpeak = category == VideoCategory.SPEAK && (_activeSpeakVideo.value == null || baseName.contains("SPEAK", ignoreCase = true))

                    val videoItem = DoliaVideoItem(
                        id = videoId,
                        name = baseName,
                        category = category,
                        url = publicUrl,
                        storagePath = storageFileName,
                        sizeBytes = bytes.size.toLong(),
                        isActiveIdle = isIdle,
                        isActiveSpeak = isSpeak,
                        createdAt = System.currentTimeMillis()
                    )

                    val dbResult = storageClient.insertVideoMetadata(
                        config = _supabaseConfig.value,
                        token = sess.token,
                        video = videoItem,
                        userId = sess.user.id
                    )

                    dbResult.onSuccess {
                        _videoUploadProgress.value = null
                        _videoLoading.value = false
                        loadVideos(sess)
                    }.onFailure { err ->
                        _videoErrorMessage.value = err.message ?: "Gagal menyimpan metadata video"
                        _videoLoading.value = false
                        _videoUploadProgress.value = null
                    }
                }.onFailure { err ->
                    _videoErrorMessage.value = err.message ?: "Upload video ke Supabase Storage gagal"
                    _videoLoading.value = false
                    _videoUploadProgress.value = null
                }
            } catch (e: Exception) {
                Log.e(TAG, "Upload error: ${e.message}", e)
                _videoErrorMessage.value = e.message ?: "Terjadi kesalahan saat upload"
                _videoLoading.value = false
                _videoUploadProgress.value = null
            }
        }
    }

    fun setActiveVideo(videoId: String, setAsIdle: Boolean, setAsSpeak: Boolean) {
        val sess = _session.value ?: return
        if (sess.user.role != UserRole.DOLIA) return

        viewModelScope.launch(Dispatchers.IO) {
            _videoLoading.value = true
            val result = storageClient.setActiveVideo(
                config = _supabaseConfig.value,
                token = sess.token,
                videoId = videoId,
                setAsIdle = setAsIdle,
                setAsSpeak = setAsSpeak
            )
            result.onSuccess {
                loadVideos(sess)
            }.onFailure { err ->
                _videoErrorMessage.value = err.message
                _videoLoading.value = false
            }
        }
    }

    fun deleteVideo(videoId: String, storagePath: String) {
        val sess = _session.value ?: return
        if (sess.user.role != UserRole.DOLIA) return

        viewModelScope.launch(Dispatchers.IO) {
            _videoLoading.value = true
            val result = storageClient.deleteVideo(
                config = _supabaseConfig.value,
                token = sess.token,
                videoId = videoId,
                storagePath = storagePath
            )
            result.onSuccess {
                loadVideos(sess)
            }.onFailure { err ->
                _videoErrorMessage.value = err.message
                _videoLoading.value = false
            }
        }
    }

    fun clearVideoError() {
        _videoErrorMessage.value = null
    }

    fun reconnect() {
        _session.value?.let { sess ->
            connectRealtime(sess)
        }
    }

    fun sendSpeak() {
        val text = _inputText.value.trim()
        if (text.isEmpty()) return

        val cmdId = "cmd_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(5)}"
        val newItem = CommandHistoryItem(
            id = cmdId,
            text = text,
            timestamp = System.currentTimeMillis(),
            status = if (realtimeClient.connectionStatus.value == ConnectionStatus.CONNECTED) "Sending..." else "Waiting Supabase..."
        )

        _commandHistory.value = listOf(newItem) + _commandHistory.value
        _inputText.value = ""

        // 1. Send via Supabase Realtime Broadcast
        val sent = realtimeClient.sendSpeakCommand(text, cmdId)
        if (sent) {
            _lastSentFeedback.value = "Teks terkirim ke Supabase Realtime"
        } else {
            _lastSentFeedback.value = "Supabase Realtime menghubungkan ulang..."
            reconnect()
        }

        // 2. Persist to PostgreSQL commands table via PostgREST (governed by RLS)
        _session.value?.let { sess ->
            viewModelScope.launch(Dispatchers.IO) {
                val dbResult = databaseClient.insertCommand(
                    config = _supabaseConfig.value,
                    token = sess.token,
                    commandId = cmdId,
                    senderId = sess.user.id,
                    text = text,
                    recipientRole = "dolia"
                )
                dbResult.onSuccess { savedItem ->
                    _commandHistory.value = _commandHistory.value.map { item ->
                        if (item.id == cmdId) savedItem else item
                    }
                }.onFailure { err ->
                    Log.w(TAG, "PostgreSQL insert note: ${err.message}")
                }
            }
        }
    }

    fun clearFeedback() {
        _lastSentFeedback.value = null
    }

    fun clearHistory() {
        _commandHistory.value = emptyList()
    }

    fun testLocalTts(sampleText: String = "Halo! Ini adalah suara Dolia AI melalui Supabase Realtime.") {
        ttsEngine.speak(sampleText)
    }

    fun logout() {
        _session.value?.let { sess ->
            viewModelScope.launch(Dispatchers.IO) {
                databaseClient.upsertDeviceStatus(
                    config = _supabaseConfig.value,
                    token = sess.token,
                    deviceId = sess.user.id,
                    userId = sess.user.id,
                    role = sess.user.role,
                    isOnline = false
                )
            }
        }

        realtimeClient.disconnect()
        ttsEngine.stop()
        sessionManager.clearSession()
        _session.value = null
        _commandHistory.value = emptyList()
        _inputText.value = ""
        _authError.value = null
        _videos.value = emptyList()
        _activeIdleVideo.value = null
        _activeSpeakVideo.value = null
    }

    override fun onCleared() {
        super.onCleared()
        realtimeClient.disconnect()
        ttsEngine.shutdown()
    }
}
