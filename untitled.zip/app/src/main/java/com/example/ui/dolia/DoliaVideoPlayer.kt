package com.example.ui.dolia

import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun DoliaVideoPlayer(
    videoUrl: String?,
    isLooping: Boolean,
    modifier: Modifier = Modifier,
    onPlaybackError: ((String) -> Unit)? = null,
    onVideoEnded: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val videoView = remember {
        VideoView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                videoView.stopPlayback()
            } catch (e: Exception) {
                Log.w("DoliaVideoPlayer", "Error stopping playback: ${e.message}")
            }
        }
    }

    LaunchedEffect(videoUrl, isLooping) {
        if (!videoUrl.isNullOrBlank()) {
            try {
                val uri = Uri.parse(videoUrl)
                videoView.setVideoURI(uri)

                videoView.setOnPreparedListener { mp ->
                    try {
                        mp.isLooping = isLooping
                        // Mute video audio so Android TTS speech is loud, clear, and unhindered
                        mp.setVolume(0f, 0f)
                        videoView.start()
                    } catch (e: Exception) {
                        Log.e("DoliaVideoPlayer", "Error onPrepared: ${e.message}")
                    }
                }

                videoView.setOnCompletionListener {
                    if (!isLooping) {
                        onVideoEnded?.invoke()
                    }
                }

                videoView.setOnErrorListener { _, what, extra ->
                    Log.w("DoliaVideoPlayer", "Playback error what=$what extra=$extra for URL $videoUrl")
                    onPlaybackError?.invoke("Gagal memuat video ($what)")
                    true // Handled
                }
            } catch (e: Exception) {
                Log.e("DoliaVideoPlayer", "Error setting video URI: ${e.message}")
                onPlaybackError?.invoke(e.message ?: "Playback error")
            }
        } else {
            videoView.stopPlayback()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { videoView },
            modifier = Modifier.fillMaxSize()
        )
    }
}
