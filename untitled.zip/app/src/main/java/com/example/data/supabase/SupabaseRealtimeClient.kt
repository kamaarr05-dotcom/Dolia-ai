package com.example.data.supabase

import android.util.Log
import com.example.data.model.ConnectionStatus
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

class SupabaseRealtimeClient(
    private val scope: CoroutineScope,
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
) {
    companion object {
        private const val TAG = "SupabaseRealtime"
        private const val REALTIME_TOPIC = "realtime:dolia_channel"
        private const val HEARTBEAT_INTERVAL_MS = 25_000L
    }

    private var webSocket: WebSocket? = null
    private var isIntentionalClose = false
    private var activeConfig: SupabaseConfig? = null
    private var activeToken: String? = null
    private var activeRole: UserRole = UserRole.CONTROLLER
    private var activeUserId: String = ""

    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null
    private val refCounter = AtomicLong(1)

    // Observable states
    private val _connectionStatus = MutableStateFlow(ConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _isDoliaOnline = MutableStateFlow(false)
    val isDoliaOnline: StateFlow<Boolean> = _isDoliaOnline.asStateFlow()

    private val _doliaCount = MutableStateFlow(0)
    val doliaCount: StateFlow<Int> = _doliaCount.asStateFlow()

    // Callbacks
    var onSpeakCommandReceived: ((text: String, id: String) -> Unit)? = null
    var onCommandAckReceived: ((id: String, status: String, count: Int) -> Unit)? = null
    var onAuthFailed: (() -> Unit)? = null

    fun connect(
        config: SupabaseConfig,
        token: String,
        role: UserRole,
        userId: String
    ) {
        isIntentionalClose = false
        activeConfig = config
        activeToken = token
        activeRole = role
        activeUserId = userId

        reconnectJob?.cancel()
        heartbeatJob?.cancel()

        _connectionStatus.value = ConnectionStatus.CONNECTING

        val wsUrl = config.realtimeWsUrl
        Log.d(TAG, "Connecting to Supabase Realtime: $wsUrl (Role: ${role.value})")

        val request = Request.Builder()
            .url(wsUrl)
            .build()

        val oldWs = webSocket
        webSocket = null
        oldWs?.close(1000, "Reconnecting")

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                if (ws !== webSocket) return
                Log.d(TAG, "Connected to Supabase Realtime WebSocket successfully")
                _connectionStatus.value = ConnectionStatus.CONNECTED

                // Join the Realtime broadcast channel
                joinChannel(ws, token)

                // Start heartbeat
                startHeartbeat(ws)

                // Announce status / request status
                if (activeRole == UserRole.DOLIA) {
                    broadcastDoliaStatus(isOnline = true, count = 1)
                } else {
                    requestDoliaStatus()
                }
            }

            override fun onMessage(ws: WebSocket, text: String) {
                if (ws !== webSocket) return
                try {
                    handleIncomingMessage(text)
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling message: ${e.message}", e)
                }
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                if (ws !== webSocket) return
                Log.d(TAG, "Supabase Realtime closing: $code / $reason")
                _connectionStatus.value = ConnectionStatus.DISCONNECTED
                _isDoliaOnline.value = false
                _doliaCount.value = 0
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                if (ws !== webSocket) return
                Log.d(TAG, "Supabase Realtime closed: $code / $reason")
                _connectionStatus.value = ConnectionStatus.DISCONNECTED
                _isDoliaOnline.value = false
                _doliaCount.value = 0
                heartbeatJob?.cancel()
                triggerReconnect()
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                if (ws !== webSocket) return
                val responseCode = response?.code ?: 0
                Log.e(TAG, "Supabase Realtime failure: ${t.message} (code: $responseCode)", t)
                _connectionStatus.value = ConnectionStatus.DISCONNECTED
                _isDoliaOnline.value = false
                _doliaCount.value = 0
                heartbeatJob?.cancel()

                if (responseCode == 401 || responseCode == 403) {
                    Log.e(TAG, "Realtime auth failure ($responseCode)")
                    onAuthFailed?.invoke()
                    return
                }

                triggerReconnect()
            }
        })
    }

    private fun joinChannel(ws: WebSocket, token: String) {
        val ref = "join_${refCounter.getAndIncrement()}"
        val joinPayload = JSONObject().apply {
            put("topic", REALTIME_TOPIC)
            put("event", "phx_join")
            put("payload", JSONObject().apply {
                put("config", JSONObject().apply {
                    put("broadcast", JSONObject().apply {
                        put("self", true)
                        put("ack", true)
                    })
                    put("presence", JSONObject().apply {
                        put("key", activeUserId)
                    })
                    put("postgres_changes", org.json.JSONArray().apply {
                        put(JSONObject().apply {
                            put("event", "INSERT")
                            put("schema", "public")
                            put("table", "commands")
                        })
                    })
                })
                put("access_token", token)
            })
            put("ref", ref)
        }.toString()

        ws.send(joinPayload)

        // Send access token explicitly for channel authorization
        val tokenPayload = JSONObject().apply {
            put("topic", REALTIME_TOPIC)
            put("event", "access_token")
            put("payload", JSONObject().apply {
                put("access_token", token)
            })
            put("ref", "token_${refCounter.getAndIncrement()}")
        }.toString()

        ws.send(tokenPayload)
    }

    private fun startHeartbeat(ws: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch(Dispatchers.IO) {
            while (isActive && _connectionStatus.value == ConnectionStatus.CONNECTED) {
                delay(HEARTBEAT_INTERVAL_MS)
                if (ws === webSocket) {
                    val hb = JSONObject().apply {
                        put("topic", "phoenix")
                        put("event", "heartbeat")
                        put("payload", JSONObject())
                        put("ref", "hb_${refCounter.getAndIncrement()}")
                    }.toString()
                    ws.send(hb)
                }
            }
        }
    }

    private fun handleIncomingMessage(rawText: String) {
        val root = JSONObject(rawText)
        val event = root.optString("event")
        val payload = root.optJSONObject("payload") ?: return

        when (event) {
            "broadcast" -> {
                val broadcastEvent = payload.optString("event")
                val data = payload.optJSONObject("payload") ?: return

                when (broadcastEvent) {
                    "speak" -> {
                        val text = data.optString("text")
                        val id = data.optString("id")
                        val recipientRole = data.optString("recipient_role", "dolia")

                        // Dolia processes speak command
                        if (activeRole == UserRole.DOLIA && (recipientRole == "dolia" || recipientRole.isEmpty())) {
                            Log.d(TAG, "Dolia received Realtime SPEAK: $text ($id)")
                            onSpeakCommandReceived?.invoke(text, id)

                            // Send broadcast ack back to controller
                            sendBroadcastAck(id)
                        }
                    }

                    "command_ack" -> {
                        val id = data.optString("id")
                        val status = data.optString("status", "delivered")
                        val count = data.optInt("count", 1)
                        if (activeRole == UserRole.CONTROLLER) {
                            Log.d(TAG, "Controller received Realtime ACK for $id")
                            onCommandAckReceived?.invoke(id, status, count)
                        }
                    }

                    "dolia_status" -> {
                        val isOnline = data.optBoolean("is_online", true)
                        val count = data.optInt("count", 1)
                        _isDoliaOnline.value = isOnline
                        _doliaCount.value = count
                        Log.d(TAG, "Realtime dolia_status updated: isOnline=$isOnline, count=$count")
                    }

                    "dolia_ping" -> {
                        // If we are Dolia and Controller asked for status, respond
                        if (activeRole == UserRole.DOLIA) {
                            broadcastDoliaStatus(isOnline = true, count = 1)
                        }
                    }
                }
            }

            "postgres_changes" -> {
                // Also listen for Postgres CDC inserts as a fallback
                val data = payload.optJSONObject("data") ?: return
                val record = data.optJSONObject("record") ?: return
                val text = record.optString("text")
                val id = record.optString("id")
                val recipientRole = record.optString("recipient_role", "dolia")

                if (activeRole == UserRole.DOLIA && recipientRole == "dolia" && text.isNotEmpty()) {
                    Log.d(TAG, "Dolia received Postgres CDC SPEAK: $text ($id)")
                    onSpeakCommandReceived?.invoke(text, id)
                    sendBroadcastAck(id)
                }
            }

            "phx_reply" -> {
                // Heartbeat / join replies
            }
        }
    }

    /**
     * Controller sends speak command via Supabase Realtime broadcast
     */
    fun sendSpeakCommand(text: String, id: String? = null): Boolean {
        if (_connectionStatus.value != ConnectionStatus.CONNECTED || webSocket == null) {
            return false
        }

        val cmdId = id ?: "cmd_${System.currentTimeMillis()}"
        val ref = "speak_${refCounter.getAndIncrement()}"

        val message = JSONObject().apply {
            put("topic", REALTIME_TOPIC)
            put("event", "broadcast")
            put("payload", JSONObject().apply {
                put("type", "broadcast")
                put("event", "speak")
                put("payload", JSONObject().apply {
                    put("id", cmdId)
                    put("text", text)
                    put("sender_id", activeUserId)
                    put("recipient_role", "dolia")
                    put("timestamp", System.currentTimeMillis())
                })
            })
            put("ref", ref)
        }.toString()

        Log.d(TAG, "Sending Realtime Speak Broadcast: $text ($cmdId)")
        return webSocket?.send(message) ?: false
    }

    private fun sendBroadcastAck(commandId: String) {
        if (_connectionStatus.value != ConnectionStatus.CONNECTED || webSocket == null) return
        val ref = "ack_${refCounter.getAndIncrement()}"
        val message = JSONObject().apply {
            put("topic", REALTIME_TOPIC)
            put("event", "broadcast")
            put("payload", JSONObject().apply {
                put("type", "broadcast")
                put("event", "command_ack")
                put("payload", JSONObject().apply {
                    put("id", commandId)
                    put("status", "delivered")
                    put("count", 1)
                })
            })
            put("ref", ref)
        }.toString()

        webSocket?.send(message)
    }

    fun broadcastDoliaStatus(isOnline: Boolean, count: Int = 1) {
        if (_connectionStatus.value != ConnectionStatus.CONNECTED || webSocket == null) return
        val ref = "status_${refCounter.getAndIncrement()}"
        val message = JSONObject().apply {
            put("topic", REALTIME_TOPIC)
            put("event", "broadcast")
            put("payload", JSONObject().apply {
                put("type", "broadcast")
                put("event", "dolia_status")
                put("payload", JSONObject().apply {
                    put("is_online", isOnline)
                    put("count", count)
                    put("device_id", activeUserId)
                })
            })
            put("ref", ref)
        }.toString()

        webSocket?.send(message)
        _isDoliaOnline.value = isOnline
        _doliaCount.value = count
    }

    private fun requestDoliaStatus() {
        if (_connectionStatus.value != ConnectionStatus.CONNECTED || webSocket == null) return
        val ref = "ping_${refCounter.getAndIncrement()}"
        val message = JSONObject().apply {
            put("topic", REALTIME_TOPIC)
            put("event", "broadcast")
            put("payload", JSONObject().apply {
                put("type", "broadcast")
                put("event", "dolia_ping")
                put("payload", JSONObject())
            })
            put("ref", ref)
        }.toString()

        webSocket?.send(message)
    }

    fun notifySpeechStatus(isSpeaking: Boolean, text: String) {
        // Broadcast speech activity status if desired
    }

    private fun triggerReconnect() {
        if (isIntentionalClose) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch(Dispatchers.IO) {
            delay(4000)
            val cfg = activeConfig
            val tok = activeToken
            if (cfg != null && tok != null && !isIntentionalClose) {
                Log.d(TAG, "Reconnecting to Supabase Realtime...")
                connect(cfg, tok, activeRole, activeUserId)
            }
        }
    }

    fun disconnect() {
        isIntentionalClose = true
        heartbeatJob?.cancel()
        reconnectJob?.cancel()
        webSocket?.close(1000, "User logout")
        webSocket = null
        _connectionStatus.value = ConnectionStatus.DISCONNECTED
        _isDoliaOnline.value = false
        _doliaCount.value = 0
    }
}
