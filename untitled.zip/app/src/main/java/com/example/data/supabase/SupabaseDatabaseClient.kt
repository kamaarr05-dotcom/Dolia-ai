package com.example.data.supabase

import android.util.Log
import com.example.data.model.CommandHistoryItem
import com.example.data.model.UserRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class SupabaseDatabaseClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    companion object {
        private const val TAG = "SupabaseDB"
    }

    private fun currentIsoTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    private fun parseIsoTimestamp(isoString: String?): Long {
        if (isoString.isNullOrEmpty()) return System.currentTimeMillis()
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            val clean = isoString.substringBefore("+").substringBefore("Z")
            sdf.parse(clean)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }

    /**
     * Inserts a speak command into PostgreSQL commands table.
     * Protected by Row Level Security: only users with role 'controller' can insert.
     */
    suspend fun insertCommand(
        config: SupabaseConfig,
        token: String,
        commandId: String,
        senderId: String,
        text: String,
        recipientRole: String = "dolia"
    ): Result<CommandHistoryItem> = withContext(Dispatchers.IO) {
        try {
            val url = "${config.restUrl}/commands"
            val payload = JSONObject().apply {
                put("id", commandId)
                put("sender_id", senderId)
                put("recipient_role", recipientRole)
                put("text", text)
                put("status", "delivered")
            }.toString()

            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = try {
                        JSONObject(body).optString("message", "Gagal menyimpan command (${response.code})")
                    } catch (e: Exception) {
                        "Gagal menyimpan command (${response.code}): $body"
                    }
                    Log.e(TAG, "Insert command failed: $errorMsg")
                    return@withContext Result.failure(IOException(errorMsg))
                }

                val item = CommandHistoryItem(
                    id = commandId,
                    text = text,
                    timestamp = System.currentTimeMillis(),
                    status = "Delivered to Dolia",
                    doliaCount = 1
                )
                Result.success(item)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error inserting command: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches command history from PostgreSQL commands table.
     * Protected by Row Level Security: Dolia only reads commands for dolia,
     * Controller reads commands they sent.
     */
    suspend fun fetchCommandHistory(
        config: SupabaseConfig,
        token: String,
        limit: Int = 30
    ): Result<List<CommandHistoryItem>> = withContext(Dispatchers.IO) {
        try {
            val url = "${config.restUrl}/commands?order=created_at.desc&limit=$limit"
            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException("Gagal mengambil riwayat (${response.code})"))
                }

                val arr = JSONArray(body)
                val list = mutableListOf<CommandHistoryItem>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val id = obj.getString("id")
                    val text = obj.getString("text")
                    val createdAtStr = obj.optString("created_at", "")
                    val status = obj.optString("status", "delivered")
                    list.add(
                        CommandHistoryItem(
                            id = id,
                            text = text,
                            timestamp = parseIsoTimestamp(createdAtStr),
                            status = if (status == "delivered") "Delivered to Dolia" else "Queued",
                            doliaCount = 1
                        )
                    )
                }
                Result.success(list)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Updates or registers device presence in PostgreSQL device_status table.
     */
    suspend fun upsertDeviceStatus(
        config: SupabaseConfig,
        token: String,
        deviceId: String,
        userId: String,
        role: UserRole,
        isOnline: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val url = "${config.restUrl}/device_status"
            val payload = JSONObject().apply {
                put("id", deviceId)
                put("user_id", userId)
                put("device_name", "Android ${role.value.replaceFirstChar { it.uppercase() }}")
                put("role", role.value)
                put("is_online", isOnline)
                put("last_seen", currentIsoTimestamp())
            }.toString()

            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .header("Prefer", "resolution=merge-duplicates")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(Unit)
                } else {
                    Result.failure(IOException("Upsert status failed (${response.code})"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Checks if any Dolia devices are currently online in PostgreSQL device_status.
     */
    suspend fun fetchDoliaOnlineStatus(
        config: SupabaseConfig,
        token: String
    ): Result<Pair<Boolean, Int>> = withContext(Dispatchers.IO) {
        try {
            val url = "${config.restUrl}/device_status?role=eq.dolia&is_online=eq.true&select=id"
            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException("Query device status failed"))
                }
                val arr = JSONArray(body)
                val count = arr.length()
                Result.success(Pair(count > 0, count))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
