package com.example.data.supabase

import android.util.Log
import com.example.data.model.AuthUser
import com.example.data.model.UserRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class SupabaseAuthResult(
    val accessToken: String,
    val refreshToken: String,
    val user: AuthUser
)

class SupabaseAuthClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    companion object {
        private const val TAG = "SupabaseAuth"
    }

    private fun resolveEmail(input: String): String {
        val clean = input.trim().lowercase()
        return if (clean.contains("@")) clean else "$clean@dolia.ai"
    }

    private fun resolveUsername(input: String): String {
        val clean = input.trim()
        return if (clean.contains("@")) clean.substringBefore("@") else clean
    }

    suspend fun login(
        config: SupabaseConfig,
        usernameOrEmail: String,
        password: String
    ): Result<SupabaseAuthResult> = withContext(Dispatchers.IO) {
        try {
            val email = resolveEmail(usernameOrEmail)
            val url = "${config.authUrl}/token?grant_type=password"
            val payload = JSONObject().apply {
                put("email", email)
                put("password", password)
            }.toString()

            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorDesc = try {
                        val errObj = JSONObject(body)
                        errObj.optString("error_description", errObj.optString("msg", "Login gagal (${response.code})"))
                    } catch (e: Exception) {
                        "Login gagal (${response.code})"
                    }
                    return@withContext Result.failure(IOException(errorDesc))
                }

                val json = JSONObject(body)
                val accessToken = json.getString("access_token")
                val refreshToken = json.optString("refresh_token", "")
                val userObj = json.getJSONObject("user")
                val userId = userObj.getString("id")
                val userEmail = userObj.optString("email", email)
                val userMeta = userObj.optJSONObject("user_metadata")

                var resolvedRole = UserRole.fromString(userMeta?.optString("role", "controller"))
                var resolvedUsername = userMeta?.optString("username", resolveUsername(usernameOrEmail)) ?: resolveUsername(usernameOrEmail)

                // Query PostgreSQL profiles table via PostgREST to fetch authoritative role & username
                try {
                    val profileRequest = Request.Builder()
                        .url("${config.restUrl}/profiles?id=eq.$userId&select=*")
                        .header("apikey", config.anonKey)
                        .header("Authorization", "Bearer $accessToken")
                        .get()
                        .build()

                    client.newCall(profileRequest).execute().use { profRes ->
                        if (profRes.isSuccessful) {
                            val profBody = profRes.body?.string().orEmpty()
                            val arr = JSONArray(profBody)
                            if (arr.length() > 0) {
                                val item = arr.getJSONObject(0)
                                resolvedRole = UserRole.fromString(item.optString("role", resolvedRole.value))
                                resolvedUsername = item.optString("username", resolvedUsername)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Could not fetch profile from PostgreSQL, using metadata: ${e.message}")
                }

                val authUser = AuthUser(
                    id = userId,
                    username = resolvedUsername,
                    email = userEmail,
                    role = resolvedRole
                )

                Result.success(SupabaseAuthResult(accessToken, refreshToken, authUser))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Login error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun register(
        config: SupabaseConfig,
        usernameOrEmail: String,
        password: String,
        role: UserRole
    ): Result<SupabaseAuthResult> = withContext(Dispatchers.IO) {
        try {
            val email = resolveEmail(usernameOrEmail)
            val username = resolveUsername(usernameOrEmail)
            val url = "${config.authUrl}/signup"

            val payload = JSONObject().apply {
                put("email", email)
                put("password", password)
                put("data", JSONObject().apply {
                    put("username", username)
                    put("role", role.value)
                })
            }.toString()

            val request = Request.Builder()
                .url(url)
                .header("apikey", config.anonKey)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorDesc = try {
                        val errObj = JSONObject(body)
                        errObj.optString("error_description", errObj.optString("msg", "Registrasi gagal (${response.code})"))
                    } catch (e: Exception) {
                        "Registrasi gagal (${response.code})"
                    }
                    return@withContext Result.failure(IOException(errorDesc))
                }

                val json = JSONObject(body)
                var accessToken = json.optString("access_token", "")
                val refreshToken = json.optString("refresh_token", "")
                val userObj = json.optJSONObject("user") ?: json
                val userId = userObj.optString("id", "")

                // If signup did not return access_token directly (e.g. requires sign-in), try logging in
                if (accessToken.isEmpty()) {
                    val loginRes = login(config, email, password)
                    if (loginRes.isSuccess) {
                        return@withContext loginRes
                    }
                }

                // Ensure profile is recorded in PostgreSQL profiles table
                if (accessToken.isNotEmpty() && userId.isNotEmpty()) {
                    try {
                        val profilePayload = JSONObject().apply {
                            put("id", userId)
                            put("username", username)
                            put("role", role.value)
                        }.toString()

                        val insertProfile = Request.Builder()
                            .url("${config.restUrl}/profiles")
                            .header("apikey", config.anonKey)
                            .header("Authorization", "Bearer $accessToken")
                            .header("Prefer", "resolution=merge-duplicates")
                            .post(profilePayload.toRequestBody(jsonMediaType))
                            .build()

                        client.newCall(insertProfile).execute().close()
                    } catch (e: Exception) {
                        Log.w(TAG, "Profile upsert note: ${e.message}")
                    }
                }

                val authUser = AuthUser(
                    id = userId,
                    username = username,
                    email = email,
                    role = role
                )

                Result.success(SupabaseAuthResult(accessToken, refreshToken, authUser))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Register error: ${e.message}", e)
            Result.failure(e)
        }
    }
}
