-- ==============================================================================
-- DOLIA V1 - Supabase Database Schema & Row Level Security (RLS)
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUMS
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('controller', 'dolia');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 3. PROFILES TABLE (Linked to auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL CHECK (role IN ('controller', 'dolia')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 4. DEVICE STATUS TABLE (Tracks device presence and status)
CREATE TABLE IF NOT EXISTS public.device_status (
    id TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    device_name TEXT NOT NULL DEFAULT 'Android Device',
    role TEXT NOT NULL CHECK (role IN ('controller', 'dolia')),
    is_online BOOLEAN NOT NULL DEFAULT false,
    last_seen TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 5. COMMANDS TABLE (Command History & Realtime stream)
CREATE TABLE IF NOT EXISTS public.commands (
    id TEXT PRIMARY KEY,
    sender_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    recipient_role TEXT NOT NULL DEFAULT 'dolia' CHECK (recipient_role IN ('controller', 'dolia')),
    text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'delivered',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Indexes for high-speed queries
CREATE INDEX IF NOT EXISTS idx_commands_created_at ON public.commands (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_commands_recipient ON public.commands (recipient_role);
CREATE INDEX IF NOT EXISTS idx_device_status_role_online ON public.device_status (role, is_online);

-- 6. ENABLE ROW LEVEL SECURITY (RLS) ON ALL TABLES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.device_status ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commands ENABLE ROW LEVEL SECURITY;

-- 7. RLS POLICIES FOR PROFILES
-- Any authenticated user can view profiles (to know roles and usernames)
DROP POLICY IF EXISTS "Authenticated users can view profiles" ON public.profiles;
CREATE POLICY "Authenticated users can view profiles"
    ON public.profiles FOR SELECT
    TO authenticated
    USING (true);

-- Users can only insert their own profile on registration
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
CREATE POLICY "Users can insert own profile"
    ON public.profiles FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);

-- Users can update their own profile, but CANNOT change their role (prevents role elevation)
DROP POLICY IF EXISTS "Users can update own profile without role change" ON public.profiles;
CREATE POLICY "Users can update own profile without role change"
    ON public.profiles FOR UPDATE
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (
        auth.uid() = id AND
        role = (SELECT role FROM public.profiles WHERE id = auth.uid())
    );

-- 8. RLS POLICIES FOR COMMANDS
-- RLS RULE 1: Controller HANYA dapat mengirim command (INSERT).
DROP POLICY IF EXISTS "Controllers can insert commands" ON public.commands;
CREATE POLICY "Controllers can insert commands"
    ON public.commands FOR INSERT
    TO authenticated
    WITH CHECK (
        auth.uid() = sender_id AND
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'controller'
        )
    );

-- RLS RULE 2: Dolia HANYA menerima command yang ditujukan kepadanya (recipient_role = 'dolia').
-- Controller juga dapat membaca command yang telah ia kirimkan sendiri untuk melihat riwayat.
DROP POLICY IF EXISTS "Dolia and Sender can select commands" ON public.commands;
CREATE POLICY "Dolia and Sender can select commands"
    ON public.commands FOR SELECT
    TO authenticated
    USING (
        -- Controller dapat membaca command miliknya sendiri
        (sender_id = auth.uid())
        OR
        -- Dolia hanya dapat membaca command yang ditujukan kepadanya
        (
            recipient_role = 'dolia' AND
            EXISTS (
                SELECT 1 FROM public.profiles
                WHERE id = auth.uid() AND role = 'dolia'
            )
        )
    );

-- 9. RLS POLICIES FOR DEVICE STATUS
-- Authenticated users can view device statuses (Controller needs to know if Dolia is online)
DROP POLICY IF EXISTS "Authenticated users can view device status" ON public.device_status;
CREATE POLICY "Authenticated users can view device status"
    ON public.device_status FOR SELECT
    TO authenticated
    USING (true);

-- Devices can insert or update their own status
DROP POLICY IF EXISTS "Devices can manage own status" ON public.device_status;
CREATE POLICY "Devices can manage own status"
    ON public.device_status FOR ALL
    TO authenticated
    USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());

-- 10. REALTIME CONFIGURATION
-- Publish tables to Supabase Realtime publication
DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.commands;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.device_status;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 11. AUTOMATIC PROFILE TRIGGER ON AUTH SIGNUP
-- Automatically creates a profile record when a new user signs up via Supabase Auth
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    default_username TEXT;
    assigned_role TEXT;
BEGIN
    default_username := COALESCE(
        new.raw_user_meta_data->>'username',
        split_part(new.email, '@', 1)
    );
    assigned_role := COALESCE(
        new.raw_user_meta_data->>'role',
        'controller'
    );

    IF assigned_role NOT IN ('controller', 'dolia') THEN
        assigned_role := 'controller';
    END IF;

    INSERT INTO public.profiles (id, username, role)
    VALUES (new.id, default_username, assigned_role)
    ON CONFLICT (id) DO UPDATE
    SET username = EXCLUDED.username,
        role = EXCLUDED.role,
        updated_at = timezone('utc'::text, now());

    RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ==============================================================================
-- 12. VIDEOS TABLE (Video Manager for Dolia Studio)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.videos (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('idle', 'speak', 'reaction')),
    url TEXT NOT NULL,
    storage_path TEXT NOT NULL,
    size_bytes BIGINT DEFAULT 0,
    uploaded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    is_active_idle BOOLEAN NOT NULL DEFAULT false,
    is_active_speak BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_videos_category ON public.videos (category);
CREATE INDEX IF NOT EXISTS idx_videos_active_idle ON public.videos (is_active_idle);
CREATE INDEX IF NOT EXISTS idx_videos_active_speak ON public.videos (is_active_speak);

ALTER TABLE public.videos ENABLE ROW LEVEL SECURITY;

-- Videos RLS: Dolia role can fully manage (SELECT, INSERT, UPDATE, DELETE)
DROP POLICY IF EXISTS "Dolia can manage videos" ON public.videos;
CREATE POLICY "Dolia can manage videos"
    ON public.videos FOR ALL
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'dolia'
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'dolia'
        )
    );

-- Read policy for authenticated users
DROP POLICY IF EXISTS "Authenticated users can view videos" ON public.videos;
CREATE POLICY "Authenticated users can view videos"
    ON public.videos FOR SELECT
    TO authenticated
    USING (true);

-- Realtime publication for videos table
DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.videos;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- ==============================================================================
-- 13. SUPABASE STORAGE BUCKET & POLICIES ('dolia-videos')
-- ==============================================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'dolia-videos',
    'dolia-videos',
    true,
    104857600,
    ARRAY['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska', 'video/*']
)
ON CONFLICT (id) DO UPDATE
SET public = true;

-- Storage RLS: Public read access for high-speed streaming
DROP POLICY IF EXISTS "Public Read dolia-videos" ON storage.objects;
CREATE POLICY "Public Read dolia-videos"
    ON storage.objects FOR SELECT
    TO public
    USING (bucket_id = 'dolia-videos');

-- Storage RLS: Authenticated Dolia users can upload videos
DROP POLICY IF EXISTS "Dolia upload to dolia-videos" ON storage.objects;
CREATE POLICY "Dolia upload to dolia-videos"
    ON storage.objects FOR INSERT
    TO authenticated
    WITH CHECK (
        bucket_id = 'dolia-videos' AND
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'dolia'
        )
    );

-- Storage RLS: Authenticated Dolia users can update and delete videos
DROP POLICY IF EXISTS "Dolia modify dolia-videos" ON storage.objects;
CREATE POLICY "Dolia modify dolia-videos"
    ON storage.objects FOR UPDATE
    TO authenticated
    USING (
        bucket_id = 'dolia-videos' AND
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'dolia'
        )
    );

DROP POLICY IF EXISTS "Dolia delete from dolia-videos" ON storage.objects;
CREATE POLICY "Dolia delete from dolia-videos"
    ON storage.objects FOR DELETE
    TO authenticated
    USING (
        bucket_id = 'dolia-videos' AND
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'dolia'
        )
    );

