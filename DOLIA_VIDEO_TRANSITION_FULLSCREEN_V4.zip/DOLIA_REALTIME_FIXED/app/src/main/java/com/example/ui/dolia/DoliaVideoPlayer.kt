package com.example.ui.dolia

import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

/**
 * Dual-buffer video player using TextureView + MediaPlayer.
 *
 * VideoView is backed by SurfaceView. Two overlapping SurfaceViews can produce
 * a black screen on Android because their hardware surfaces are composed
 * independently. TextureView renders into the normal view hierarchy, so two
 * players can safely overlap while the next clip is prepared.
 */
private class DualTextureVideoController(
    private val container: FrameLayout,
    private val onPlaybackError: ((String) -> Unit)?,
    private val onVideoEnded: (() -> Unit)?
) {
    private data class Slot(
        val view: TextureView,
        var player: MediaPlayer? = null,
        var url: String? = null,
        var prepared: Boolean = false,
        var surfaceReady: Boolean = false,
        var surface: Surface? = null,
        var requestedToken: Long = 0L,
        var isLooping: Boolean = false
    )

    private val slots: List<Slot>
    private var activeIndex = 0
    private var requestToken = 0L
    private var disposed = false

    init {
        val first = TextureView(container.context)
        val second = TextureView(container.context)
        slots = listOf(Slot(first), Slot(second))

        slots.forEachIndexed { index, slot ->
            slot.view.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            slot.view.alpha = if (index == activeIndex) 1f else 0f
            slot.view.visibility = View.VISIBLE
            slot.view.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(
                    surface: android.graphics.SurfaceTexture,
                    width: Int,
                    height: Int
                ) {
                    if (disposed) return
                    slot.surface?.release()
                    slot.surface = Surface(surface)
                    slot.surfaceReady = true
                    attachAndMaybeStart(slot)
                }

                override fun onSurfaceTextureSizeChanged(
                    surface: android.graphics.SurfaceTexture,
                    width: Int,
                    height: Int
                ) = Unit

                override fun onSurfaceTextureDestroyed(surface: android.graphics.SurfaceTexture): Boolean {
                    slot.surfaceReady = false
                    slot.surface?.release()
                    slot.surface = null
                    try { slot.player?.setSurface(null) } catch (_: Exception) { }
                    return true
                }

                override fun onSurfaceTextureUpdated(surface: android.graphics.SurfaceTexture) = Unit
            }
            container.addView(slot.view)
        }
    }

    fun play(url: String?, isLooping: Boolean) {
        if (disposed) return
        if (url.isNullOrBlank()) {
            slots.forEach { releaseSlot(it) }
            return
        }

        val active = slots[activeIndex]
        if (active.url == url && active.prepared) {
            active.isLooping = isLooping
            active.player?.isLooping = isLooping
            attachAndMaybeStart(active)
            showOnly(activeIndex)
            return
        }

        val preparedIndex = slots.indexOfFirst { it.url == url && it.prepared && it.surfaceReady }
        if (preparedIndex >= 0) {
            slots[preparedIndex].isLooping = isLooping
            switchTo(preparedIndex)
            return
        }

        val targetIndex = 1 - activeIndex
        val target = slots[targetIndex]
        val token = ++requestToken
        releasePlayerOnly(target)
        target.requestedToken = token
        target.url = url
        target.prepared = false
        target.isLooping = isLooping
        target.view.alpha = 0f

        try {
            val player = MediaPlayer()
            target.player = player
            player.setAudioStreamType(AudioManager.STREAM_MUSIC)
            player.setVolume(1f, 1f)
            player.isLooping = isLooping
            player.setOnPreparedListener { mp ->
                if (disposed || target.requestedToken != token || target.url != url) {
                    return@setOnPreparedListener
                }
                target.prepared = true
                mp.isLooping = target.isLooping
                mp.setVolume(1f, 1f)
                attachAndMaybeStart(target)
            }
            player.setOnCompletionListener {
                if (!disposed && target === slots[activeIndex]) {
                    onVideoEnded?.invoke()
                }
            }
            player.setOnErrorListener { _, what, extra ->
                if (!disposed && target === slots[activeIndex]) {
                    Log.e(TAG, "MediaPlayer error what=$what extra=$extra url=${target.url}")
                    onPlaybackError?.invoke("Gagal memuat video ($what/$extra)")
                }
                true
            }

            val uri = if (url.startsWith("/")) Uri.fromFile(File(url)) else Uri.parse(url)
            if (url.startsWith("/")) {
                player.setDataSource(url)
            } else {
                player.setDataSource(container.context, uri)
            }
            player.prepareAsync()
        } catch (e: Exception) {
            Log.e(TAG, "Error preparing video url=$url", e)
            onPlaybackError?.invoke(e.message ?: "Playback error")
        }
    }

    private fun attachAndMaybeStart(slot: Slot) {
        if (disposed || !slot.prepared || !slot.surfaceReady) return
        val player = slot.player ?: return
        try {
            slot.surface?.let { player.setSurface(it) }
            player.isLooping = slot.isLooping
            player.setVolume(1f, 1f)
            if (slot === slots[activeIndex]) {
                player.start()
            } else {
                // The hidden target is intentionally kept prepared but paused.
                // This makes the next transition immediate without racing the UI.
                if (player.isPlaying) player.pause()
            }
            if (slot === slots[activeIndex]) showOnly(activeIndex)
        } catch (e: Exception) {
            Log.e(TAG, "Error attaching/resuming video", e)
            onPlaybackError?.invoke(e.message ?: "Playback error")
        }
    }

    private fun switchTo(index: Int) {
        if (disposed || index !in slots.indices) return
        val next = slots[index]
        if (!next.prepared || !next.surfaceReady) return
        val oldIndex = activeIndex
        val old = slots[oldIndex]
        try { old.player?.pause() } catch (_: Exception) { }
        activeIndex = index
        try {
            next.surface?.let { next.player?.setSurface(it) }
            next.player?.setVolume(1f, 1f)
            next.player?.isLooping = next.isLooping
            next.player?.start()
        } catch (e: Exception) {
            Log.e(TAG, "Error switching video", e)
            onPlaybackError?.invoke(e.message ?: "Playback switch error")
            return
        }
        showOnly(index)
    }

    private fun showOnly(index: Int) {
        slots.forEachIndexed { i, slot ->
            slot.view.alpha = if (i == index) 1f else 0f
            slot.view.bringToFront()
        }
    }

    private fun releasePlayerOnly(slot: Slot) {
        try { slot.player?.stop() } catch (_: Exception) { }
        try { slot.player?.reset() } catch (_: Exception) { }
        try { slot.player?.release() } catch (_: Exception) { }
        slot.player = null
        slot.prepared = false
    }

    private fun releaseSlot(slot: Slot) {
        releasePlayerOnly(slot)
        slot.url = null
        slot.requestedToken = ++requestToken
        slot.surface?.release()
        slot.surface = null
        slot.surfaceReady = false
        slot.view.alpha = 0f
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        slots.forEach { slot ->
            releasePlayerOnly(slot)
            slot.surface?.release()
            slot.surface = null
            slot.surfaceReady = false
        }
    }

    companion object {
        private const val TAG = "DoliaVideoPlayer"
    }
}

@Composable
fun DoliaVideoPlayer(
    videoUrl: String?,
    isLooping: Boolean,
    modifier: Modifier = Modifier,
    onPlaybackError: ((String) -> Unit)? = null,
    onVideoEnded: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val latestError = androidx.compose.runtime.rememberUpdatedState(onPlaybackError)
    val latestEnded = androidx.compose.runtime.rememberUpdatedState(onVideoEnded)
    val container = remember {
        FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(android.graphics.Color.BLACK)
        }
    }
    val controller = remember(container) {
        DualTextureVideoController(
            container = container,
            onPlaybackError = { latestError.value?.invoke(it) },
            onVideoEnded = { latestEnded.value?.invoke() }
        )
    }

    DisposableEffect(controller) {
        onDispose { controller.dispose() }
    }

    LaunchedEffect(videoUrl, isLooping) {
        controller.play(videoUrl, isLooping)
    }

    AndroidView(
        factory = { container },
        modifier = modifier.fillMaxSize()
    )
}
