package com.example.ui.dolia

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * Stable single-player video surface.
 *
 * Media3/ExoPlayer is used instead of swapping MediaPlayer/TextureView surfaces.
 * PlayerView keeps the current frame while a replacement item is prepared, then
 * switches to the new item once it is ready. This avoids the freeze/black frame
 * seen with the previous dual-player implementation.
 */
@Composable
fun DoliaVideoPlayer(
    videoUrl: String?,
    isLooping: Boolean,
    modifier: Modifier = Modifier,
    onPlaybackError: ((String) -> Unit)? = null,
    onVideoEnded: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val latestError = rememberUpdatedState(onPlaybackError)
    val latestEnded = rememberUpdatedState(onVideoEnded)

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            volume = 1f
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    latestEnded.value?.invoke()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                latestError.value?.invoke(error.message ?: "Gagal memutar video")
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(videoUrl, isLooping) {
        if (videoUrl.isNullOrBlank()) return@LaunchedEffect

        val sameItem = player.currentMediaItem?.localConfiguration?.uri?.toString() == videoUrl
        player.repeatMode = if (isLooping) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF

        if (sameItem) {
            if (!player.isPlaying && player.playbackState != Player.STATE_ENDED) {
                player.play()
            }
            return@LaunchedEffect
        }

        // Keep the current rendered frame while the new media is prepared.
        // PlayerView's keepContentOnPlayerReset=true prevents a blank frame.
        player.setMediaItem(MediaItem.fromUri(videoUrl), /* resetPosition = */ true)
        player.prepare()
        player.playWhenReady = true
    }

    AndroidView(
        factory = {
            PlayerView(it).apply {
                useController = false
                keepContentOnPlayerReset = true
                setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                player = player
            }
        },
        modifier = modifier
    )
}
