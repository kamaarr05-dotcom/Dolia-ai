-- DOLIA Realtime: private Studio-specific channels
-- Topic format used by the APK:
-- realtime:dolia_studio_<STUDIO_USER_ID>
--
-- A Studio may read/write only its own topic.
-- A Controller may read/write only the topic of its paired studio_id.

alter table realtime.messages enable row level security;

grant usage on schema realtime to authenticated;
grant select, insert on realtime.messages to authenticated;

drop policy if exists "dolia_receive_own_studio_broadcasts" on realtime.messages;
create policy "dolia_receive_own_studio_broadcasts"
on realtime.messages
for select
to authenticated
using (
  extension = 'broadcast'
  and exists (
    select 1
    from public.dolia_profiles p
    where p.id = auth.uid()
      and (
        (p.role = 'STUDIO'
         and p.id::text = replace(realtime.topic(), 'realtime:dolia_studio_', ''))
        or
        (p.role = 'CONTROLLER'
         and p.studio_id::text = replace(realtime.topic(), 'realtime:dolia_studio_', ''))
      )
  )
);

drop policy if exists "dolia_send_own_studio_broadcasts" on realtime.messages;
create policy "dolia_send_own_studio_broadcasts"
on realtime.messages
for insert
to authenticated
with check (
  extension = 'broadcast'
  and exists (
    select 1
    from public.dolia_profiles p
    where p.id = auth.uid()
      and (
        (p.role = 'STUDIO'
         and p.id::text = replace(realtime.topic(), 'realtime:dolia_studio_', ''))
        or
        (p.role = 'CONTROLLER'
         and p.studio_id::text = replace(realtime.topic(), 'realtime:dolia_studio_', ''))
      )
  )
);
