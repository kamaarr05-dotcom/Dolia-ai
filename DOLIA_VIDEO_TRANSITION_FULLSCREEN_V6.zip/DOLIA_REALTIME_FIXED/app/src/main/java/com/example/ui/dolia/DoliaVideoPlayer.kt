package com.example.ui.dolia

import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

/**
 * Single-surface seamless video controller.
 *
 * A single TextureView stays on screen for the entire lifetime of the player.
 * When the URL changes, a second MediaPlayer prepares in the background while
 * the current player remains attached and visible. Only after the new player
 * is prepared do we attach it to the same surface and start it, then release
 * the old player. This avoids the black frame caused by replacing the visible
 * view/player before the next clip is ready.
 */
private class SeamlessTextureVideoController(
    private val container: FrameLayout,
    private val onPlaybackError: ((String) -> Unit)?,
    private val onVideoEnded: (() -> Unit)?
) {
    private val textureView = TextureView(container.context)
    private var surface: Surface? = null
    private var activePlayer: MediaPlayer? = null
    private var activeUrl: String? = null
    private var activeLooping = false
    private var pendingPlayer: MediaPlayer? = null
    private var pendingUrl: String? = null
    private var pendingLooping = false
    private var pendingPrepared = false
    private var requestToken = 0L
    private var disposed = false

    init {
        textureView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(
                surfaceTexture: android.graphics.SurfaceTexture,
                width: Int,
                height: Int
            ) {
                if (disposed) return
                surface?.release()
                surface = Surface(surfaceTexture)
                activePlayer?.let { attachAndStartIfReady(it, activeLooping) }
                pendingPlayer?.let { if (pendingPrepared) switchPrepared(it) }
            }

            override fun onSurfaceTextureSizeChanged(
                surfaceTexture: android.graphics.SurfaceTexture,
                width: Int,
                height: Int
            ) = Unit

            override fun onSurfaceTextureDestroyed(surfaceTexture: android.graphics.SurfaceTexture): Boolean {
                surface?.release()
                surface = null
                try { activePlayer?.setSurface(null) } catch (_: Exception) { }
                try { pendingPlayer?.setSurface(null) } catch (_: Exception) { }
                return true
            }

            override fun onSurfaceTextureUpdated(surfaceTexture: android.graphics.SurfaceTexture) = Unit
        }
        container.addView(textureView)
    }

    fun play(url: String?, isLooping: Boolean) {
        if (disposed) return
        if (url.isNullOrBlank()) return

        val current = activePlayer
        if (activeUrl == url && current != null) {
            activeLooping = isLooping
            try { current.isLooping = isLooping } catch (_: Exception) { }
            if (surface != null && !current.isPlaying) {
                attachAndStartIfReady(current, isLooping)
            }
            return
        }

        // If this exact URL is already being prepared, just update its loop mode.
        if (pendingUrl == url && pendingPlayer != null) {
            pendingLooping = isLooping
            try { pendingPlayer?.isLooping = isLooping } catch (_: Exception) { }
            return
        }

        val token = ++requestToken
        releasePending()
        pendingUrl = url
        pendingLooping = isLooping
        pendingPrepared = false

        val player = try { MediaPlayer() } catch (e: Exception) {
            onPlaybackError?.invoke(e.message ?: "Gagal membuat pemutar video")
            return
        }
        pendingPlayer = player

        try {
            player.setAudioStreamType(AudioManager.STREAM_MUSIC)
            player.setVolume(1f, 1f)
            player.isLooping = isLooping

            player.setOnPreparedListener { mp ->
                if (disposed || token != requestToken || pendingPlayer !== mp || pendingUrl != url) {
                    try { mp.release() } catch (_: Exception) { }
                    return@setOnPreparedListener
                }
                try {
                    mp.isLooping = pendingLooping
                    mp.setVolume(1f, 1f)
                    pendingPrepared = true
                    if (surface == null) return@setOnPreparedListener
                    switchPrepared(mp)
                } catch (e: Exception) {
                    Log.e(TAG, "Error switching prepared video", e)
                    onPlaybackError?.invoke(e.message ?: "Gagal menampilkan video")
                }
            }

            player.setOnCompletionListener { mp ->
                if (!disposed && mp === activePlayer && !activeLooping) {
                    onVideoEnded?.invoke()
                }
            }

            player.setOnErrorListener { mp, what, extra ->
                if (!disposed && (mp === activePlayer || mp === pendingPlayer)) {
                    Log.e(TAG, "MediaPlayer error what=$what extra=$extra url=${if (mp === activePlayer) activeUrl else pendingUrl}")
                    if (mp === pendingPlayer) {
                        releasePending()
                    }
                    onPlaybackError?.invoke("Gagal memuat video ($what/$extra)")
                }
                true
            }

            if (url.startsWith("/")) {
                player.setDataSource(url)
            } else {
                player.setDataSource(container.context, Uri.parse(url))
            }
            player.prepareAsync()
        } catch (e: Exception) {
            Log.e(TAG, "Error preparing video url=$url", e)
            if (pendingPlayer === player) releasePending()
            onPlaybackError?.invoke(e.message ?: "Gagal memuat video")
        }
    }

    private fun attachAndStartIfReady(player: MediaPlayer, looping: Boolean) {
        if (disposed || surface == null) return
        try {
            player.setSurface(surface)
            player.isLooping = looping
            player.setVolume(1f, 1f)
            if (!player.isPlaying) player.start()
        } catch (e: Exception) {
            Log.e(TAG, "Error attaching active video", e)
        }
    }

    private fun attachPendingIfReady(player: MediaPlayer) {
        if (pendingPrepared) switchPrepared(player)
    }

    private fun switchPrepared(mp: MediaPlayer) {
        if (disposed || pendingPlayer !== mp || pendingUrl.isNullOrBlank() || surface == null) return
        try {
            val newUrl = pendingUrl!!
            val newLooping = pendingLooping
            // The old player remains visible until this point.
            mp.setSurface(surface)
            mp.isLooping = newLooping
            mp.setVolume(1f, 1f)
            mp.start()

            val old = activePlayer
            activePlayer = mp
            activeUrl = newUrl
            activeLooping = newLooping
            pendingPlayer = null
            pendingUrl = null
            pendingPrepared = false
            old?.let { releasePlayer(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Error switching prepared video", e)
            onPlaybackError?.invoke(e.message ?: "Gagal menampilkan video")
        }
    }

    private fun releasePending() {
        pendingPlayer?.let { releasePlayer(it) }
        pendingPlayer = null
        pendingUrl = null
        pendingPrepared = false
    }

    private fun releasePlayer(player: MediaPlayer) {
        try { player.stop() } catch (_: Exception) { }
        try { player.reset() } catch (_: Exception) { }
        try { player.release() } catch (_: Exception) { }
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        ++requestToken
        releasePending()
        activePlayer?.let { releasePlayer(it) }
        activePlayer = null
        activeUrl = null
        surface?.release()
        surface = null
    }

    companion object {
        private const val TAG = "DoliaVideoPlayer"
    }
}

@Composable
fun DoliaVideoPlayer(
    videoUrl: String?,
    isLooping: Boolean,
    modifier: Modifier = Modifier,
    onPlaybackError: ((String) -> Unit)? = null,
    onVideoEnded: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val latestError = androidx.compose.runtime.rememberUpdatedState(onPlaybackError)
    val latestEnded = androidx.compose.runtime.rememberUpdatedState(onVideoEnded)
    val container = remember {
        FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(android.graphics.Color.BLACK)
        }
    }
    val controller = remember(container) {
        SeamlessTextureVideoController(
            container = container,
            onPlaybackError = { latestError.value?.invoke(it) },
            onVideoEnded = { latestEnded.value?.invoke() }
        )
    }

    DisposableEffect(controller) {
        onDispose { controller.dispose() }
    }

    LaunchedEffect(videoUrl, isLooping) {
        controller.play(videoUrl, isLooping)
    }

    AndroidView(
        factory = { container },
        modifier = modifier
    )
}
