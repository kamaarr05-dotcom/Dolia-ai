# DOLIA — Supabase Auth tanpa verifikasi email

DOLIA menggunakan login email/username + password. Akun yang sudah terdaftar tidak perlu mengirim OTP atau email verifikasi setiap kali login.

## Supabase Cloud (wajib dilakukan di Dashboard)

Supabase Cloud tidak mengambil pengaturan `config.toml` ini. Pada project Supabase yang dipakai DOLIA:

1. Buka **Authentication**.
2. Buka **Providers** / provider **Email**.
3. Matikan **Confirm Email** (atau **Enable email confirmations**).
4. Simpan perubahan.

Setelah **Confirm Email** dimatikan, Supabase menganggap email pengguna terkonfirmasi dan pengguna dapat masuk dengan password tanpa verifikasi email. Jangan menggunakan OTP/magic-link untuk alur login DOLIA.

## Supabase CLI / local / self-hosted

Gunakan `supabase/config.toml` yang ada di folder ini. Nilai pentingnya adalah:

```toml
[auth.email]
enable_confirmations = false
```

## Catatan akun lama

Mematikan Confirm Email memengaruhi aturan login untuk project. Akun yang status emailnya masih belum terkonfirmasi pada project Cloud perlu diperiksa statusnya di Auth Users bila masih ditolak saat login. Aplikasi tidak mengirim ulang email saat proses LOGIN.
